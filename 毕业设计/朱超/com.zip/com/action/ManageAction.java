package com.action;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;

import com.dao.DingdanDao;
import com.dao.GonggaoDao;
import com.dao.LeibieDao;
import com.dao.LiuyanDao;
import com.dao.PicDao;
import com.dao.ProductDao;
import com.dao.UserDao;
import com.model.Dingdan;
import com.model.Gonggao;
import com.model.Leibie;
import com.model.Liuyan;
import com.model.Pic;
import com.model.Product;
import com.model.User;
import com.opensymphony.xwork2.ActionSupport;
import com.util.Pager;
import com.util.Util;

public class ManageAction extends ActionSupport {

	private static final long serialVersionUID = -4304509122548259589L;

	private String url = "./";

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	// 获取请求对象
	public HttpServletRequest getRequest() {
		HttpServletRequest request = ServletActionContext.getRequest();
		return request;
	}

	// 获取响应对象
	public HttpServletResponse getResponse() {
		HttpServletResponse response = ServletActionContext.getResponse();
		return response;
	}

	// 获取session对象
	public HttpSession getSession() {
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpSession session = request.getSession();
		return session;
	}

	// 获取输出对象
	public PrintWriter getPrintWriter() {

		HttpServletResponse response = ServletActionContext.getResponse();
		response.setCharacterEncoding("utf-8");
		response.setContentType("text/html; charset=utf-8");
		PrintWriter writer = null;
		try {
			writer = response.getWriter();
		} catch (IOException e) {
			e.printStackTrace();
		}

		return writer;
	}

	private UserDao userDao;

	public UserDao getUserDao() {
		return userDao;
	}

	public void setUserDao(UserDao userDao) {
		this.userDao = userDao;
	}

	// 登入请求
	public String login() throws IOException {
		HttpServletRequest request = this.getRequest();
		PrintWriter writer = this.getPrintWriter();
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		User user = userDao.selectBean(" where username = '" + username
				+ "' and password= '" + password + "'"
				+ " and deletestatus=0 and role=0");
		if (user != null) {
			HttpSession session = request.getSession();
			session.setAttribute("user", user);
			this.setUrl("manage/index.jsp");
			return "redirect";
		} else {
			writer
					.print("<script language=javascript>alert('用户名或者密码错误');window.location.href='manage/login.jsp';</script>");
		}
		return null;
	}

	// 用户退出
	public String loginout() {
		HttpServletRequest request = this.getRequest();
		HttpSession session = request.getSession();
		session.removeAttribute("user");
		this.setUrl("manage/login.jsp");
		return SUCCESS;
	}

	// 跳转到修改密码页面
	public String changepwd() {
		this.setUrl("manage/password.jsp");
		return SUCCESS;
	}

	// 修改密码操作
	public void changepwd2() throws IOException {
		HttpServletRequest request = this.getRequest();
		PrintWriter writer = this.getPrintWriter();
		HttpSession session = request.getSession();
		User u = (User) session.getAttribute("user");
		String password1 = request.getParameter("password1");
		String password2 = request.getParameter("password2");
		User bean = userDao.selectBean(" where username= '" + u.getUsername()
				+ "' and password= '" + password1 + "' and deletestatus=0");
		if (bean != null) {
			bean.setPassword(password2);
			userDao.updateBean(bean);
			writer
					.print("<script language=javascript>alert('修改成功');window.location.href='method!changepwd';</script>");
		} else {
			writer
					.print("<script language=javascript>alert('原密码错误');window.location.href='method!changepwd';</script>");
		}
	}
	
	
	
	private LeibieDao leibieDao;

	public LeibieDao getLeibieDao() {
		return leibieDao;
	}

	public void setLeibieDao(LeibieDao leibieDao) {
		this.leibieDao = leibieDao;
	}

	// 类别列表
	public String leibielist() {
		HttpServletRequest request = this.getRequest();
		String lname = request.getParameter("lname");

		StringBuffer sb = new StringBuffer();
		sb.append(" where ");

		if (lname != null && !"".equals(lname)) {

			sb.append("lname like '%" + lname + "%'");
			sb.append(" and ");
			request.setAttribute("lname", lname);
		}

		sb.append("   deletestatus=0 order by id desc ");
		String where = sb.toString();

		int currentpage = 1;
		int pagesize = 10;
		if (request.getParameter("pagenum") != null) {
			currentpage = Integer.parseInt(request.getParameter("pagenum"));
		}
		int total = leibieDao.selectBeanCount(where.replaceAll(
				"order by id desc", ""));
		request.setAttribute("list", leibieDao.selectBeanList((currentpage - 1)
				* pagesize, pagesize, where));
		request.setAttribute("pagerinfo", Pager.getPagerNormal(total, pagesize,
				currentpage, "method!leibielist", "共有" + total + "条记录"));
		request.setAttribute("url", "method!leibielist");
		request.setAttribute("url2", "method!leibie");
		request.setAttribute("title", "类别管理");
		this.setUrl("manage/leibie/leibielist.jsp");
		return SUCCESS;

	}

	// 跳转到添加类别页面
	public String leibieadd() {
		HttpServletRequest request = this.getRequest();

		request.setAttribute("url", "method!leibieadd2");
		request.setAttribute("title", "添加新类别");
		this.setUrl("manage/leibie/leibieadd.jsp");
		return SUCCESS;
	}

	// 添加类别操作
	public void leibieadd2() throws IOException {
		HttpServletRequest request = this.getRequest();
		PrintWriter writer = this.getPrintWriter();

		String lname = request.getParameter("lname");

		Leibie bean = new Leibie();
		bean.setLname(lname);
		leibieDao.insertBean(bean);

		writer
				.print("<script language=javascript>alert('操作成功');window.location.href='method!leibielist';</script>");

	}

	// 跳转到更新类别页面
	public String leibieupdate() {
		HttpServletRequest request = this.getRequest();
		Leibie bean = leibieDao.selectBean(" where id= "
				+ request.getParameter("id"));
		request.setAttribute("bean", bean);
		request.setAttribute("url", "method!leibieupdate2?id=" + bean.getId());
		request.setAttribute("title", "类别修改");
		this.setUrl("manage/leibie/leibieupdate.jsp");
		return SUCCESS;
	}

	// 更新类别操作
	public void leibieupdate2() throws IOException {
		HttpServletRequest request = this.getRequest();
		PrintWriter writer = this.getPrintWriter();

		String lname = request.getParameter("lname");

		Leibie bean = leibieDao.selectBean(" where id= "
				+ request.getParameter("id"));

		bean.setLname(lname);

		leibieDao.updateBean(bean);

		writer
				.print("<script language=javascript>alert('操作成功');window.location.href='method!leibielist';</script>");
	}

	// 删除类别操作
	public void leibiedelete() throws IOException {
		HttpServletRequest request = this.getRequest();
		PrintWriter writer = this.getPrintWriter();
		Leibie bean = leibieDao.selectBean(" where id= "
				+ request.getParameter("id"));
		bean.setDeletestatus(1);
		leibieDao.updateBean(bean);

		writer
				.print("<script language=javascript>alert('操作成功');window.location.href='method!leibielist';</script>");
	}

	// 跳转到查看类别页面
	public String leibieupdate3() {
		HttpServletRequest request = this.getRequest();
		Leibie bean = leibieDao.selectBean(" where id= "
				+ request.getParameter("id"));
		request.setAttribute("bean", bean);
		request.setAttribute("title", "类别查看");
		this.setUrl("manage/leibie/leibieupdate3.jsp");
		return SUCCESS;
	}
	
	
	private ProductDao productDao;

	public ProductDao getProductDao() {
		return productDao;
	}

	public void setProductDao(ProductDao productDao) {
		this.productDao = productDao;
	}
	
	
	
	// 商品列表
	public String productlist() {
		HttpServletRequest request = this.getRequest();
		String mingchen = request.getParameter("mingchen");

		StringBuffer sb = new StringBuffer();
		sb.append(" where ");

		if (mingchen != null && !"".equals(mingchen)) {

			sb.append("mingchen like '%" + mingchen + "%'");
			sb.append(" and ");
			request.setAttribute("mingchen", mingchen);
		}

		sb.append("   deletestatus=0 order by id desc ");
		String where = sb.toString();

		int currentpage = 1;
		int pagesize = 10;
		if (request.getParameter("pagenum") != null) {
			currentpage = Integer.parseInt(request.getParameter("pagenum"));
		}
		int total = productDao.selectBeanCount(where.replaceAll(
				"order by id desc", ""));
		request.setAttribute("list", productDao.selectBeanList((currentpage - 1)
				* pagesize, pagesize, where));
		request.setAttribute("pagerinfo", Pager.getPagerNormal(total, pagesize,
				currentpage, "method!productlist", "共有" + total + "条记录"));
		request.setAttribute("url", "method!productlist");
		request.setAttribute("url2", "method!product");
		request.setAttribute("title", "商品管理");
		this.setUrl("manage/product/productlist.jsp");
		return SUCCESS;

	}

	// 跳转到添加商品页面
	public String productadd() {
		HttpServletRequest request = this.getRequest();

		request.setAttribute("leibielist", leibieDao.selectBeanList(0, 9999,
				" where deletestatus=0  "));
		request.setAttribute("url", "method!productadd2");
		request.setAttribute("title", "添加新商品");
		this.setUrl("manage/product/productadd.jsp");
		return SUCCESS;
	}

	private File uploadfile;

	public File getUploadfile() {
		return uploadfile;
	}

	public void setUploadfile(File uploadfile) {
		this.uploadfile = uploadfile;
	}

	// 添加商品操作
	public void productadd2() throws IOException {
		HttpServletRequest request = this.getRequest();
		PrintWriter writer = this.getPrintWriter();

		String jiage = request.getParameter("jiage");
		String miaoshu = request.getParameter("miaoshu");
		String mingchen = request.getParameter("mingchen");
		String leibieid = request.getParameter("leibieid");

		Product bean = new Product();

		if (uploadfile != null) {
			String savapath = ServletActionContext.getServletContext()
					.getRealPath("/")
					+ "/uploadfile/";
			String time = Util.getTime2();
			String imgpath = time + ".jpg";
			File file = new File(savapath + imgpath);
			Util.copyFile(uploadfile, file);
			bean.setTupian(imgpath);
		}
		bean.setJiage(Double.parseDouble(jiage));
		bean.setMiaoshu(miaoshu);
		bean.setMingchen(mingchen);
		bean.setShijian(Util.getRiqi());
		bean.setTuijian("未推荐");
		bean.setDianji(0);
		bean.setLeibie(leibieDao.selectBean(" where id= " + leibieid));

		productDao.insertBean(bean);

		writer
				.print("<script language=javascript>alert('操作成功');window.location.href='method!productlist';</script>");

	}

	// 跳转到更新商品页面
	public String productupdate() {
		HttpServletRequest request = this.getRequest();
		Product bean = productDao.selectBean(" where id= "
				+ request.getParameter("id"));
		request.setAttribute("leibielist", leibieDao.selectBeanList(0, 9999,
				" where deletestatus=0  "));

		request.setAttribute("bean", bean);
		request.setAttribute("url", "method!productupdate2?id=" + bean.getId());
		request.setAttribute("title", "商品修改");
		this.setUrl("manage/product/productupdate.jsp");
		return SUCCESS;
	}

	// 更新商品操作
	public void productupdate2() throws IOException {
		HttpServletRequest request = this.getRequest();
		PrintWriter writer = this.getPrintWriter();

		String jiage = request.getParameter("jiage");
		String miaoshu = request.getParameter("miaoshu");
		String mingchen = request.getParameter("mingchen");
		String leibieid = request.getParameter("leibieid");

		Product bean = productDao.selectBean(" where id= "
				+ request.getParameter("id"));

		if (uploadfile != null) {
			String savapath = ServletActionContext.getServletContext()
					.getRealPath("/")
					+ "/uploadfile/";
			String time = Util.getTime2();
			String imgpath = time + "01.jpg";
			File file = new File(savapath + imgpath);
			Util.copyFile(uploadfile, file);
			bean.setTupian(imgpath);
		}
		bean.setJiage(Double.parseDouble(jiage));
		bean.setMiaoshu(miaoshu);
		bean.setMingchen(mingchen);
		bean.setLeibie(leibieDao.selectBean(" where id= " + leibieid));
		productDao.updateBean(bean);

		writer
				.print("<script language=javascript>alert('操作成功');window.location.href='method!productlist';</script>");
	}

	// 删除商品操作
	public void productdelete() throws IOException {
		HttpServletRequest request = this.getRequest();
		PrintWriter writer = this.getPrintWriter();
		Product bean = productDao.selectBean(" where id= "
				+ request.getParameter("id"));
		bean.setDeletestatus(1);
		productDao.updateBean(bean);

		writer
				.print("<script language=javascript>alert('操作成功');window.location.href='method!productlist';</script>");
	}

	// 跳转到查看商品页面
	public String productupdate3() {
		HttpServletRequest request = this.getRequest();
		Product bean = productDao.selectBean(" where id= "
				+ request.getParameter("id"));
		request.setAttribute("bean", bean);
		request.setAttribute("title", "商品查看");
		this.setUrl("manage/product/productupdate3.jsp");
		return SUCCESS;
	}

	// 推荐商品操作
	public void productdelete2() throws IOException {
		HttpServletRequest request = this.getRequest();
		PrintWriter writer = this.getPrintWriter();
		Product bean = productDao.selectBean(" where id= "
				+ request.getParameter("id"));
		bean.setTuijian("推荐");
		productDao.updateBean(bean);

		writer
				.print("<script language=javascript>alert('操作成功');window.location.href='method!productlist';</script>");
	}

	// 取消推荐商品操作
	public void productdelete3() throws IOException {
		HttpServletRequest request = this.getRequest();
		PrintWriter writer = this.getPrintWriter();
		Product bean = productDao.selectBean(" where id= "
				+ request.getParameter("id"));
		bean.setTuijian("未推荐");
		;
		productDao.updateBean(bean);

		writer
				.print("<script language=javascript>alert('操作成功');window.location.href='method!productlist';</script>");
	}
	
	
	private DingdanDao dingdanDao;

	public DingdanDao getDingdanDao() {
		return dingdanDao;
	}

	public void setDingdanDao(DingdanDao dingdanDao) {
		this.dingdanDao = dingdanDao;
	}

	// 订单列表
	public String dingdanlist() {
		HttpServletRequest request = this.getRequest();
		String orderid = request.getParameter("orderid");

		String status = request.getParameter("status");

		StringBuffer sb = new StringBuffer();
		sb.append(" where ");

		if (orderid != null && !"".equals(orderid)) {

			sb.append("orderid like '%" + orderid + "%'");
			sb.append(" and ");
			request.setAttribute("orderid", orderid);
		}

		if (status != null && !"".equals(status)) {

			sb.append("status like '%" + status + "%'");
			sb.append(" and ");
			request.setAttribute("status", status);
		}

		sb.append("   deletestatus=0 order by id desc ");
		String where = sb.toString();

		int currentpage = 1;
		int pagesize = 10;
		if (request.getParameter("pagenum") != null) {
			currentpage = Integer.parseInt(request.getParameter("pagenum"));
		}
		int total = dingdanDao.selectBeanCount(where.replaceAll(
				"order by id desc", ""));
		request.setAttribute("list", dingdanDao.selectBeanList(
				(currentpage - 1) * pagesize, pagesize, where));
		request.setAttribute("pagerinfo", Pager.getPagerNormal(total, pagesize,
				currentpage, "method!dingdanlist", "共有" + total + "条记录"));
		request.setAttribute("url", "method!dingdanlist");
		request.setAttribute("url2", "method!dingdan");
		request.setAttribute("title", "订单管理");
		this.setUrl("manage/dingdan/dingdanlist.jsp");
		return SUCCESS;

	}

	
	// 处理订单操作
	public void dingdandelete2() throws IOException {
		HttpServletRequest request = this.getRequest();
		PrintWriter writer = this.getPrintWriter();
		Dingdan bean = dingdanDao.selectBean(" where id= "
				+ request.getParameter("id"));

		bean.setStatus("完成订单");

		dingdanDao.updateBean(bean);

		writer
				.print("<script language=javascript>alert('操作成功');window.location.href='method!dingdanlist';</script>");
	}

	// 跳转到查看订单页面
	public String dingdanupdate3() {
		HttpServletRequest request = this.getRequest();
		Dingdan bean = dingdanDao.selectBean(" where id= "
				+ request.getParameter("id"));
		request.setAttribute("bean", bean);
		request.setAttribute("title", "订单查看");
		this.setUrl("manage/dingdan/dingdanupdate3.jsp");
		return SUCCESS;
	}

	// 会员列表
	public String userlist() {
		HttpServletRequest request = this.getRequest();
		String username = request.getParameter("username");

		StringBuffer sb = new StringBuffer();
		sb.append(" where ");

		if (username != null && !"".equals(username)) {

			sb.append("username like '%" + username + "%'");
			sb.append(" and ");
			request.setAttribute("username", username);
		}

		sb.append("   deletestatus=0  and role=1 order by id desc ");
		String where = sb.toString();

		int currentpage = 1;
		int pagesize = 10;
		if (request.getParameter("pagenum") != null) {
			currentpage = Integer.parseInt(request.getParameter("pagenum"));
		}
		int total = userDao.selectBeanCount(where.replaceAll(
				"order by id desc", ""));
		request.setAttribute("list", userDao.selectBeanList((currentpage - 1)
				* pagesize, pagesize, where));
		request.setAttribute("pagerinfo", Pager.getPagerNormal(total, pagesize,
				currentpage, "method!userlist", "共有" + total + "条记录"));
		request.setAttribute("url", "method!userlist");
		request.setAttribute("url2", "method!user");
		request.setAttribute("title", "会员管理");
		this.setUrl("manage/user/userlist.jsp");
		return SUCCESS;

	}

	// 删除会员操作
	public void userdelete() throws IOException {
		HttpServletRequest request = this.getRequest();
		PrintWriter writer = this.getPrintWriter();
		User bean = userDao.selectBean(" where id= "
				+ request.getParameter("id"));

		bean.setDeletestatus(1);

		userDao.updateBean(bean);

		writer
				.print("<script language=javascript>alert('操作成功');window.location.href='method!userlist';</script>");
	}
	
	
	private LiuyanDao liuyanDao;

	public LiuyanDao getLiuyanDao() {
		return liuyanDao;
	}

	public void setLiuyanDao(LiuyanDao liuyanDao) {
		this.liuyanDao = liuyanDao;
	}
	
	

	
	// 留言列表
	public String liuyanlist() {
		HttpServletRequest request = this.getRequest();
		String ltitle = request.getParameter("ltitle");

		StringBuffer sb = new StringBuffer();
		sb.append(" where ");

		if (ltitle != null && !"".equals(ltitle)) {

			sb.append("ltitle like '%" + ltitle + "%'");
			sb.append(" and ");
			request.setAttribute("ltitle", ltitle);
		}

		sb.append("   deletestatus=0 order by id desc ");
		String where = sb.toString();

		int currentpage = 1;
		int pagesize = 10;
		if (request.getParameter("pagenum") != null) {
			currentpage = Integer.parseInt(request.getParameter("pagenum"));
		}
		int total = liuyanDao.selectBeanCount(where.replaceAll(
				"order by id desc", ""));
		request.setAttribute("list", liuyanDao.selectBeanList((currentpage - 1)
				* pagesize, pagesize, where));
		request.setAttribute("pagerinfo", Pager.getPagerNormal(total, pagesize,
				currentpage, "method!liuyanlist", "共有" + total + "条记录"));
		request.setAttribute("url", "method!liuyanlist");
		request.setAttribute("url2", "method!liuyan");
		request.setAttribute("title", "留言管理");
		this.setUrl("manage/liuyan/liuyanlist.jsp");
		return SUCCESS;

	}

	
	// 跳转回复页面
	public String liuyanupdate() {
		HttpServletRequest request = this.getRequest();
		Liuyan bean = liuyanDao.selectBean(" where id= "
				+ request.getParameter("id"));
		
		request.setAttribute("bean", bean);
		request.setAttribute("url", "method!liuyanupdate2?id=" + bean.getId());
		request.setAttribute("title", "回复留言");
		this.setUrl("manage/liuyan/liuyanupdate.jsp");
		return SUCCESS;
	}

	// 更新留言操作
	public void liuyanupdate2() throws IOException {
		HttpServletRequest request = this.getRequest();
		PrintWriter writer = this.getPrintWriter();

		String huifu = request.getParameter("huifu");

		Liuyan bean = liuyanDao.selectBean(" where id= "
				+ request.getParameter("id"));

		bean.setHuifu(huifu);
		bean.setHtime(Util.getTime());
		bean.setStatus("已回复");
		
		
		liuyanDao.updateBean(bean);

		writer
				.print("<script language=javascript>alert('操作成功');window.location.href='method!liuyanlist';</script>");
	}

	

	// 跳转到查看留言页面
	public String liuyanupdate3() {
		HttpServletRequest request = this.getRequest();
		Liuyan bean = liuyanDao.selectBean(" where id= "
				+ request.getParameter("id"));
		request.setAttribute("bean", bean);
		request.setAttribute("title", "留言查看");
		this.setUrl("manage/liuyan/liuyanupdate3.jsp");
		return SUCCESS;
	}
	
	
	private GonggaoDao gonggaoDao;

	public GonggaoDao getGonggaoDao() {
		return gonggaoDao;
	}

	public void setGonggaoDao(GonggaoDao gonggaoDao) {
		this.gonggaoDao = gonggaoDao;
	}
	
	
	// 网站公告列表
	public String gonggaolist() {
		HttpServletRequest request = this.getRequest();
		String gbiaoti = request.getParameter("gbiaoti");

		StringBuffer sb = new StringBuffer();
		sb.append(" where ");

		if (gbiaoti != null && !"".equals(gbiaoti)) {

			sb.append("gbiaoti like '%" + gbiaoti + "%'");
			sb.append(" and ");
			request.setAttribute("gbiaoti", gbiaoti);
		}

		sb.append("   deletestatus=0 order by id desc ");
		String where = sb.toString();

		int currentpage = 1;
		int pagesize = 10;
		if (request.getParameter("pagenum") != null) {
			currentpage = Integer.parseInt(request.getParameter("pagenum"));
		}
		int total = gonggaoDao.selectBeanCount(where.replaceAll(
				"order by id desc", ""));
		request.setAttribute("list", gonggaoDao.selectBeanList((currentpage - 1)
				* pagesize, pagesize, where));
		request.setAttribute("pagerinfo", Pager.getPagerNormal(total, pagesize,
				currentpage, "method!gonggaolist", "共有" + total + "条记录"));
		request.setAttribute("url", "method!gonggaolist");
		request.setAttribute("url2", "method!gonggao");
		request.setAttribute("title", "网站公告管理");
		this.setUrl("manage/gonggao/gonggaolist.jsp");
		return SUCCESS;

	}

	// 跳转到添加网站公告页面
	public String gonggaoadd() {
		HttpServletRequest request = this.getRequest();

		request.setAttribute("url", "method!gonggaoadd2");
		request.setAttribute("title", "添加网站公告");
		this.setUrl("manage/gonggao/gonggaoadd.jsp");
		return SUCCESS;
	}

	// 添加网站公告操作
	public void gonggaoadd2() throws IOException {
		HttpServletRequest request = this.getRequest();
		PrintWriter writer = this.getPrintWriter();

		String gbiaoti = request.getParameter("gbiaoti");
		String neirong = request.getParameter("neirong");

		Gonggao bean = new Gonggao();
		
		bean.setGbiaoti(gbiaoti);
		bean.setNeirong(neirong);
		bean.setShijian(Util.getRiqi());
		
		gonggaoDao.insertBean(bean);

		writer
				.print("<script language=javascript>alert('操作成功');window.location.href='method!gonggaolist';</script>");

	}

	// 跳转到更新网站公告页面
	public String gonggaoupdate() {
		HttpServletRequest request = this.getRequest();
		Gonggao bean = gonggaoDao.selectBean(" where id= "
				+ request.getParameter("id"));
		request.setAttribute("bean", bean);
		request.setAttribute("url", "method!gonggaoupdate2?id=" + bean.getId());
		request.setAttribute("title", "网站公告修改");
		this.setUrl("manage/gonggao/gonggaoupdate.jsp");
		return SUCCESS;
	}

	// 更新网站公告操作
	public void gonggaoupdate2() throws IOException {
		HttpServletRequest request = this.getRequest();
		PrintWriter writer = this.getPrintWriter();

		String gbiaoti = request.getParameter("gbiaoti");
		String neirong = request.getParameter("neirong");


		Gonggao bean = gonggaoDao.selectBean(" where id= "
				+ request.getParameter("id"));

		bean.setGbiaoti(gbiaoti);
		bean.setNeirong(neirong);

		gonggaoDao.updateBean(bean);

		writer
				.print("<script language=javascript>alert('操作成功');window.location.href='method!gonggaolist';</script>");
	}

	// 删除网站公告操作
	public void gonggaodelete() throws IOException {
		HttpServletRequest request = this.getRequest();
		PrintWriter writer = this.getPrintWriter();
		Gonggao bean = gonggaoDao.selectBean(" where id= "
				+ request.getParameter("id"));
		bean.setDeletestatus(1);
		gonggaoDao.updateBean(bean);

		writer
				.print("<script language=javascript>alert('操作成功');window.location.href='method!gonggaolist';</script>");
	}

	// 跳转到查看网站公告页面
	public String gonggaoupdate3() {
		HttpServletRequest request = this.getRequest();
		Gonggao bean = gonggaoDao.selectBean(" where id= "
				+ request.getParameter("id"));
		request.setAttribute("bean", bean);
		request.setAttribute("title", "网站公告查看");
		this.setUrl("manage/gonggao/gonggaoupdate3.jsp");
		return SUCCESS;
	}
	
	private PicDao picDao;

	public PicDao getPicDao() {
		return picDao;
	}

	public void setPicDao(PicDao picDao) {
		this.picDao = picDao;
	}
	
	
	// 网站动态图片列表
	public String piclist() {
		HttpServletRequest request = this.getRequest();
		
		StringBuffer sb = new StringBuffer();
		sb.append(" where ");

		

		sb.append("   0=0 order by id desc ");
		String where = sb.toString();

		int currentpage = 1;
		int pagesize = 10;
		if (request.getParameter("pagenum") != null) {
			currentpage = Integer.parseInt(request.getParameter("pagenum"));
		}
		int total = picDao.selectBeanCount(where.replaceAll(
				"order by id desc", ""));
		request.setAttribute("list", picDao.selectBeanList((currentpage - 1)
				* pagesize, pagesize, where));
		request.setAttribute("pagerinfo", Pager.getPagerNormal(total, pagesize,
				currentpage, "method!piclist", "共有" + total + "条记录"));
		request.setAttribute("url", "method!piclist");
		request.setAttribute("url2", "method!pic");
		request.setAttribute("title", "网站动态图片管理");
		this.setUrl("manage/pic/piclist.jsp");
		return SUCCESS;

	}


	// 跳转到更新网站动态图片页面
	public String picupdate() {
		HttpServletRequest request = this.getRequest();
		Pic bean = picDao.selectBean(" where id= "
				+ request.getParameter("id"));
		request.setAttribute("bean", bean);
		request.setAttribute("url", "method!picupdate2?id=" + bean.getId());
		request.setAttribute("title", "网站动态图片修改");
		this.setUrl("manage/pic/picupdate.jsp");
		return SUCCESS;
	}

	// 更新网站动态图片操作
	public void picupdate2() throws IOException {
		HttpServletRequest request = this.getRequest();
		PrintWriter writer = this.getPrintWriter();

		String href = request.getParameter("href");
		String info = request.getParameter("info");

		Pic bean = picDao.selectBean(" where id= "
				+ request.getParameter("id"));

		bean.setHref(href);
		bean.setInfo(info);
		
		if(uploadfile!=null){
			String savapath = ServletActionContext.getServletContext().getRealPath("/")+"/uploadfile/";
			String time = Util.getTime2();
			String imgpath = time+".jpg";
			File file = new File(savapath+imgpath);
			Util.copyFile(uploadfile, file);

			bean.setPath(imgpath);
		}

		picDao.updateBean(bean);

		writer
				.print("<script language=javascript>alert('操作成功');window.location.href='method!piclist';</script>");
	}
	
}

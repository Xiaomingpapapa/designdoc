package com.action;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;

import com.dao.DingdanDao;
import com.dao.GonggaoDao;
import com.dao.GouwucheDao;
import com.dao.LiuyanDao;
import com.dao.ProductDao;
import com.dao.UserDao;
import com.model.Dingdan;
import com.model.Gonggao;
import com.model.Gouwuche;
import com.model.Liuyan;
import com.model.Product;
import com.model.User;
import com.opensymphony.xwork2.ActionSupport;
import com.util.Arith;
import com.util.Pager;
import com.util.Util;

public class IndexAction extends ActionSupport {

	private static final long serialVersionUID = -4304509122548259589L;

	private String url = "./";

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	// 获取请求对象
	public HttpServletRequest getRequest() {
		HttpServletRequest request = ServletActionContext.getRequest();
		return request;
	}

	// 获取响应对象
	public HttpServletResponse getResponse() {
		HttpServletResponse response = ServletActionContext.getResponse();
		return response;
	}

	// 获取session对象
	public HttpSession getSession() {
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpSession session = request.getSession();
		return session;
	}

	// 获取输出对象
	public PrintWriter getPrintWriter() {

		HttpServletResponse response = ServletActionContext.getResponse();
		response.setCharacterEncoding("utf-8");
		response.setContentType("text/html; charset=utf-8");
		PrintWriter writer = null;
		try {
			writer = response.getWriter();
		} catch (IOException e) {
			e.printStackTrace();
		}

		return writer;
	}
	
	private ProductDao productDao;

	public ProductDao getProductDao() {
		return productDao;
	}

	public void setProductDao(ProductDao productDao) {
		this.productDao = productDao;
	}
	
	
	private GonggaoDao gonggaoDao;
	
	
	
	
	public GonggaoDao getGonggaoDao() {
		return gonggaoDao;
	}

	public void setGonggaoDao(GonggaoDao gonggaoDao) {
		this.gonggaoDao = gonggaoDao;
	}

	// 网站首页
	public String index() throws Exception {

		HttpServletRequest request = this.getRequest();
		
		String mingchen = request.getParameter("mingchen");
		
		String jiage1 = request.getParameter("jiage1");
		
		String jiage2 = request.getParameter("jiage2");
		
		String miaoshu = request.getParameter("miaoshu");
		
		String tuijian = request.getParameter("tuijian");
		
		String type = request.getParameter("type");

		String leibie = request.getParameter("leibie");
		
		
		StringBuffer sb = new StringBuffer();
		sb.append(" where ");

		if (mingchen != null && !"".equals(mingchen)) {

			sb.append("mingchen like '%" + mingchen + "%'");
			sb.append(" and ");
			request.setAttribute("mingchen",mingchen );
		}
		
		if (miaoshu != null && !"".equals(miaoshu)) {

			sb.append("miaoshu like '%" + miaoshu + "%'");
			sb.append(" and ");
			request.setAttribute("miaoshu",miaoshu );
		}
		
		if (jiage1 != null && !"".equals(jiage1)) {

			sb.append("jiage >=" + jiage1 + "");
			sb.append(" and ");
			request.setAttribute("jiage1",jiage1 );
			
		}
		
		if (jiage2 != null && !"".equals(jiage2)) {

			sb.append("jiage <=" + jiage2 + "");
			sb.append(" and ");
			request.setAttribute("jiage2",jiage2 );
			
		}
		
		if (leibie != null && !"".equals(leibie)) {

			sb.append("leibie.id=" + leibie + "");
			sb.append(" and ");
			request.setAttribute("leibie",leibie );
			
		}
		
		
		if ("1".equals(tuijian)) {

			sb.append("tuijian ='推荐'");
			sb.append(" and ");
			
		}
		
		String where = "";
		
		int total = 0;
		
		if("1".equals(type)){
			sb.append("   deletestatus=0 order by buy desc ");
			
			where = sb.toString();
			
			total = productDao.selectBeanCount(where.replaceAll("order by buy desc", ""));
			
		}
		else if("2".equals(type)){
			sb.append("   deletestatus=0 order by dianji desc ");
			
			where = sb.toString();
			
			total = productDao.selectBeanCount(where.replaceAll("order by dianji desc", ""));
			
		}
		else if("3".equals(type)){
			sb.append("   deletestatus=0 order by id desc ");
			
			where = sb.toString();
			
			total = productDao.selectBeanCount(where.replaceAll("order by id desc", ""));
			
		}else{
			sb.append("   deletestatus=0 order by id desc ");
			
			where = sb.toString();
			
			total = productDao.selectBeanCount(where.replaceAll("order by id desc", ""));
			
		}
		
		
		


		int currentpage = 1;
		int pagesize = 15;
		if (request.getParameter("pagenum") != null) {
			currentpage = Integer.parseInt(request.getParameter("pagenum"));
		}
		
		
		request.setAttribute("list", productDao.selectBeanList((currentpage - 1)* pagesize, pagesize, where));
		
		request.setAttribute("pagerinfo", Pager.getPagerNormal(total, pagesize,currentpage, ".", "共有" + total + "条记录"));
	
		request.setAttribute("gonggaolist", gonggaoDao.selectBeanList(0, 10, " where deletestatus=0 order by id desc "));
		
		return "success";
	}
	
	
	
	// 跳转到查看商品页面
	public String product()  {
		HttpServletRequest request = this.getRequest();
		Product bean = productDao.selectBean(" where id= "+ request.getParameter("id"));
		bean.setDianji(bean.getDianji()+1);
		
		productDao.updateBean(bean);
		
		request.setAttribute("bean", bean);
		request.setAttribute("title", "商品详情");

		this.setUrl("product.jsp");
		return SUCCESS;

	}
	
	
	private UserDao userDao;
	
	
	public UserDao getUserDao() {
		return userDao;
	}

	public void setUserDao(UserDao userDao) {
		this.userDao = userDao;
	}
	
	

	// 跳转到用户注册页面
	public String register() {
		HttpServletRequest request = this.getRequest();

		request.setAttribute("url", "indexmethod!register2");
		request.setAttribute("title", "用户注册");
		this.setUrl("register.jsp");
		return SUCCESS;
	}

	//用户注册操作
	public void register2() throws IOException {
		HttpServletRequest request = this.getRequest();

		PrintWriter writer = this.getPrintWriter();

		String address = request.getParameter("address");
		String dianhua = request.getParameter("dianhua");
		String password = request.getParameter("password");
		String username = request.getParameter("username");
		String xingming = request.getParameter("xingming");
		
		
		User bean = userDao.selectBean(" where deletestatus=0 and username='"+ username + "' ");
		if (bean == null) {
			bean = new User();
			bean.setAddress(address);
			bean.setCreatetime(Util.getTime());
			bean.setDianhua(dianhua);
			bean.setPassword(password);
			bean.setRole(1);
			bean.setUsername(username);
			bean.setXingming(xingming);
			
			userDao.insertBean(bean);
			
						
			writer
					.print("<script language=javascript>alert('注册成功');window.location.href='.';</script>");
		} else {
			writer
					.print("<script language=javascript>alert('注册失败，该用户名已经存在');window.location.href='indexmethod!register';</script>");
		}

	}
	
	
	// 跳转到登录页面
	public String login() {
		HttpServletRequest request = this.getRequest();

		request.setAttribute("url", "indexmethod!login2");
		request.setAttribute("title", "登录");
		this.setUrl("login.jsp");
		return SUCCESS;
	}

	// 登录操作
	public void login2() throws IOException {
		HttpServletRequest request = this.getRequest();

		PrintWriter writer = this.getPrintWriter();

		String username = request.getParameter("username");
		String password = request.getParameter("password");

		User bean = userDao.selectBean(" where username = '" + username+ "' and password= '" + password+ "' and deletestatus=0 and role!=0 ");

		if (bean != null) {
			HttpSession session = request.getSession();
			session.setAttribute("qiantai", bean);

			writer
					.print("<script language=javascript>alert('登录成功');window.location.href='.';</script>");
		} else {
			writer
					.print("<script language=javascript>alert('用户名或者密码错误');window.location.href='indexmethod!login';</script>");
		}

	}

	// 用户退出
	public void loginout() throws IOException {
		HttpServletRequest request =  this.getRequest();
		PrintWriter writer = this.getPrintWriter();	
		HttpSession session = request.getSession();
		session.removeAttribute("qiantai");
		writer.print("<script language=javascript>alert('退出成功');window.location.href='.';</script>");
	}
	
	
	
	// 跳转到修改密码
	public String userupdate3() {
		HttpServletRequest request = this.getRequest();

		request.setAttribute("url", "indexmethod!userupdate4");
		request.setAttribute("title", "修改密码");
		this.setUrl("userupdate3.jsp");
		return SUCCESS;
	}

	//修改密码操作
	public void userupdate4() throws IOException {
		HttpServletRequest request = this.getRequest();

		PrintWriter writer = this.getPrintWriter();

	
		String password1 = request.getParameter("password1");
		String password2 = request.getParameter("password2");
		
		HttpSession session = request.getSession();
		User user = (User)session.getAttribute("qiantai");

		User bean = userDao.selectBean(" where username = '" + user.getUsername()+ "' and password= '" + password1+ "' and deletestatus=0 ");

		if (bean == null) {
			writer
			.print("<script language=javascript>alert('原密码错误，修改失败');window.location.href='indexmethod!userupdate3';</script>");

			
		} else {
			bean.setPassword(password2);
			
			userDao.updateBean(bean);
			
			writer
					.print("<script language=javascript>alert('修改成功');window.location.href='indexmethod!userupdate3';</script>");
		}

	}
	
	
	// 跳转到修改个人信息
	public String userupdate() {
		HttpServletRequest request = this.getRequest();

		HttpSession session = request.getSession();
		User user = (User)session.getAttribute("qiantai");

		User bean = userDao.selectBean(" where id= "+user.getId());
		
		request.setAttribute("bean", bean);
		
		request.setAttribute("url", "indexmethod!userupdate2");
		request.setAttribute("title", "个人信息");
		this.setUrl("userupdate.jsp");
		return SUCCESS;
	}

	//修改个人信息操作
	public void userupdate2() throws IOException {
		HttpServletRequest request = this.getRequest();

		PrintWriter writer = this.getPrintWriter();

	
		String address = request.getParameter("address");
		String dianhua = request.getParameter("dianhua");
		String xingming = request.getParameter("xingming");
		
		HttpSession session = request.getSession();
		User user = (User)session.getAttribute("qiantai");

		User bean = userDao.selectBean(" where id= "+user.getId());
		
		bean.setAddress(address);
		bean.setDianhua(dianhua);
		bean.setXingming(xingming);
		
		userDao.updateBean(bean);

		writer
		.print("<script language=javascript>alert('修改成功');window.location.href='indexmethod!userupdate';</script>");
	}
	
	

	
	private GouwucheDao gouwucheDao;

	public GouwucheDao getGouwucheDao() {
		return gouwucheDao;
	}

	public void setGouwucheDao(GouwucheDao gouwucheDao) {
		this.gouwucheDao = gouwucheDao;
	}
	
	//购物车列表
	public String gouwuchelist() throws IOException {
		HttpServletRequest request = this.getRequest();
		PrintWriter writer = this.getPrintWriter();	
		HttpSession session = request.getSession();
		User user = (User)session.getAttribute("qiantai");
		if(user==null){
			writer.print("<script language=javascript>alert('请先登录');window.location.href='indexmethod!login';</script>");
			return null;
		}
		
		StringBuffer sb = new StringBuffer();
		sb.append(" where ");
	

		sb.append("   user.id="+user.getId()+" order by id desc ");
		String where = sb.toString();


		int currentpage = 1;
		int pagesize = 9999;
		if (request.getParameter("pagenum") != null) {
			currentpage = Integer.parseInt(request.getParameter("pagenum"));
		}
		List<Gouwuche> list =  gouwucheDao.selectBeanList((currentpage - 1)* pagesize, pagesize, where);
		for(Gouwuche bean:list){
			bean.setTotal(Arith.mul(bean.getSl(), bean.getProduct().getJiage()));
			
		}
		
		request.setAttribute("list",list );

		double zongjia = 0;
		for(Gouwuche bean:list){
			double jiage = Arith.mul(bean.getSl(),bean.getProduct().getJiage());
			
			zongjia  = zongjia + jiage;
				}
		request.setAttribute("zongjia", zongjia);
		
		
		request.setAttribute("title", "我的购物车");
		
		this.setUrl("gouwuchelist.jsp");
		return SUCCESS;

	}
	
	
	
	//添加到购物车操作
	public void gouwucheadd() throws IOException {
		HttpServletRequest request = this.getRequest();
		PrintWriter writer = this.getPrintWriter();	
		
		HttpSession session = request.getSession();
		User user = (User)session.getAttribute("qiantai");
		if(user==null){
			
			writer.print("<script language=javascript>alert('请先登录');window.location.href='indexmethod!login';</script>");
			return;
		}
		
		String cid = request.getParameter("cid");
		Product c = productDao.selectBean(" where id= "+cid);
		
		
		
		
		Gouwuche bean = gouwucheDao.selectBean(" where product.id= "+cid +" and user.id= "+user.getId());
		if(bean==null){
			bean = new Gouwuche();
			bean.setCreatetime(Util.getTime());
			bean.setSl(1);
			bean.setUser(user);
			bean.setProduct(c);
			gouwucheDao.insertBean(bean);
			writer.print("<script language=javascript>alert('操作成功');window.location.href='indexmethod!product?id="+cid+"';</script>");
		}else{
			writer.print("<script language=javascript>alert('该商品已经存在购物车中，请勿重复添加！');window.location.href='indexmethod!product?id="+cid+"';</script>");
		}

	}
	
	
	//删除购物车中的商品操作
	public void gouwuchedelete() throws IOException {
		HttpServletRequest request = this.getRequest();
		PrintWriter writer = this.getPrintWriter();	
		Gouwuche bean = gouwucheDao.selectBean(" where id= "+ request.getParameter("id"));
		
		gouwucheDao.deleteBean(bean);
		
		writer.print("<script language=javascript>alert('操作成功');window.location.href='indexmethod!gouwuchelist';</script>");
	}
	
	
	//修改购物车的数量的操作
	public void gouwucheupdate() throws IOException{
		HttpServletRequest request = this.getRequest();
		PrintWriter writer = this.getPrintWriter();	
		
		String sl = request.getParameter("sl");
		Gouwuche gouwuche = gouwucheDao.selectBean(" where id= "+request.getParameter("id"));

		gouwuche.setSl(Integer.parseInt(sl));

		gouwucheDao.updateBean(gouwuche);

		writer.print("<script  language='javascript'>alert('操作成功');" +"window.location.href='indexmethod!gouwuchelist'; </script>");
			
	}
	
	private DingdanDao dingdanDao;

	public DingdanDao getDingdanDao() {
		return dingdanDao;
	}

	public void setDingdanDao(DingdanDao dingdanDao) {
		this.dingdanDao = dingdanDao;
	}
	
	
	
	
	
	//跳转到客户填写收件信息页面
	public String dingdanadd() throws IOException{
		HttpServletRequest request = this.getRequest();
		PrintWriter writer = this.getPrintWriter();	
		HttpSession session = request.getSession();
		User user = (User)session.getAttribute("qiantai");
		
		String sjname = request.getParameter("sjname");
		if(sjname!=null){
			writer.print("<script  language='javascript'>alert('操作成功');" +"window.location.href='indexmethod!dingdanlist'; </script>");
			return null;
		}
		
		List<Gouwuche> list2 = gouwucheDao.selectBeanList(0, 9999, " where user.id="+user.getId());
		if(list2.size()<=0){
			writer.print("<script  language='javascript'>alert('操作失败，购物车不能为空！');window.location.href='indexmethod!gouwuchelist'; </script>");
			return null;
		}
		
		
		
		
		
		request.setAttribute("title", "添加收货信息");
		request.setAttribute("url", "indexmethod!dingdanadd2");
		this.setUrl("dingdanadd.jsp");
		return SUCCESS;
	}
	
	
	//添加订单操作
	public void dingdanadd2() throws IOException{
		HttpServletRequest request = this.getRequest();
		
		
		String sjname = request.getParameter("sjname");
		String phone = request.getParameter("phone");
		String beizhu = request.getParameter("beizhu");
		String address =request.getParameter("address");
		
		HttpSession session = request.getSession();
		User user = (User) session.getAttribute("qiantai");
			
		String order_id_ = "";
		
		int order_id = dingdanDao.selectBeanCount("")+1;
		if(order_id<10){
			order_id_ = "00000"+order_id;
		}else if(order_id<100){
			order_id_ = "0000"+order_id;
		}else if(order_id<1000){
			order_id_ = "000"+order_id;
		}else if(order_id<10000){
			order_id_ = "00"+order_id;
		}else if(order_id<100000){
			order_id_ = "0"+order_id;
		}else if(order_id<1000000){
			order_id_ = ""+order_id;
		}
		
		
		Dingdan bean = new Dingdan();
		
		bean.setAddress(address);
		bean.setBeizhu(beizhu);
		bean.setCreatetime(Util.getTime());
	    bean.setDeletestatus(0);
		bean.setOrderid(order_id_);
		bean.setPhone(phone);
		bean.setSjname(sjname);
		bean.setStatus("未处理");
		bean.setUser(user);
	
		
		List<Gouwuche> list = gouwucheDao.selectBeanList(0, 9999, " where user.id="+user.getId());
		StringBuffer sb = new StringBuffer();
		double zongjia = 0;
		for(Gouwuche g:list){
			double price = 0;
			
			price = g.getProduct().getJiage();
			
			
			sb.append(" 商品名:"+g.getProduct().getMingchen() +",购买数量:"+g.getSl()  +",单价"+price 
					+",￥小计"+ Arith.mul(g.getSl(), price)+"<br/>") ;
			
			Product product = g.getProduct();
			product.setBuy(product.getBuy()+g.getSl());
			
			productDao.updateBean(product);
			
	
			gouwucheDao.deleteBean(g);
			
			
			
			zongjia = zongjia+(Arith.mul(g.getSl(), price));
			
		
			
		}
		
		bean.setXiangqing(sb.toString());
		bean.setZongjia(zongjia);
		dingdanDao.insertBean(bean);
		PrintWriter writer = this.getPrintWriter();	
		writer.print("<script  language='javascript'>alert('操作成功');window.location.href='indexmethod!dingdanlist'; </script>");
		
	}
	
	
	//查看订单列表
	public String dingdanlist() throws IOException{
		HttpServletRequest request = this.getRequest();
		PrintWriter writer = this.getPrintWriter();	
		HttpSession session = request.getSession();
		User user = (User) session.getAttribute("qiantai");
		if (user == null) {
			
			writer.print("<script  language='javascript'>alert('请先登录');window.location.href='indexmethod!login'; </script>");
			return null ;
		}
		
		String orderid = request.getParameter("orderid");
		StringBuffer sb = new StringBuffer();
		sb.append(" where ");

		


		if (orderid != null && !"".equals(orderid)) {

			sb.append("orderid like '%" + orderid + "%'");
			sb.append(" and ");
			request.setAttribute("orderid", orderid);
		}
		
		
		sb.append(" user.id="+user.getId()+" and deletestatus=0 order by id desc ");

		String where = sb.toString();


		int currentpage = 1;
		int pagesize = 10;
		if(request.getParameter("pagenum") != null){
			currentpage = Integer.parseInt(request.getParameter("pagenum"));
		}
		
		long total = dingdanDao.selectBeanCount(where.replaceAll("order by id desc", ""));
		List<Dingdan> list = dingdanDao.selectBeanList((currentpage-1)*pagesize, pagesize, where);
		request.setAttribute("list", list);
		String pagerinfo = Pager.getPagerNormal((int)total, pagesize, currentpage, "indexmethod!dingdanlist", "共有"+total+"条记录");
		request.setAttribute("pagerinfo", pagerinfo);
	
		request.setAttribute("list", list);
		request.setAttribute("url", "indexmethod!dingdanlist");
		request.setAttribute("url2", "indexmethod!dingdan");
		request.setAttribute("title", "我的订单");
		this.setUrl("dingdanlist.jsp");
		return SUCCESS;
	}
	
	
	//跳转到订单详细信息页面
	public String dingdanupdate3(){
		HttpServletRequest request = this.getRequest();

		request.setAttribute("title", "订单详情");
		String id = request.getParameter("id");
		Dingdan bean =dingdanDao.selectBean(" where id= "+id );
		request.setAttribute("bean", bean);
		this.setUrl("dingdanupdate3.jsp");
		return SUCCESS;
	}
	
	
	//取消订单操作
	public void dingdandelete() throws IOException{
		HttpServletRequest request = this.getRequest();
		PrintWriter writer = this.getPrintWriter();	
		
		Dingdan bean = dingdanDao.selectBean(" where id= "+request.getParameter("id"));
		
		bean.setStatus("取消订单");
		
		dingdanDao.updateBean(bean);

		writer.print("<script  language='javascript'>alert('操作成功');window.location.href='indexmethod!dingdanlist'; </script>");
		
	}
	
	private LiuyanDao liuyanDao;

	public LiuyanDao getLiuyanDao() {
		return liuyanDao;
	}

	public void setLiuyanDao(LiuyanDao liuyanDao) {
		this.liuyanDao = liuyanDao;
	}
	
	//跳转到留言页面
	public String liuyan()  {
		HttpServletRequest request = this.getRequest();
		HttpSession session = request.getSession();
		User uu = (User)session.getAttribute("qiantai");
		if(uu==null){
			PrintWriter writer = this.getPrintWriter();	
			writer.print("<script language=javascript>alert('请先登录');window.location.href='indexmethod!login';</script>");
			return null;
		}
		
		String tourid = request.getParameter("tourid");
		request.setAttribute("url", "indexmethod!liuyan2?tourid="+tourid);
		
		request.setAttribute("title", "留言");
		this.setUrl("liuyan.jsp");
		return SUCCESS;

	}
	
	
	//留言操作
	public void liuyan2() throws IOException {
		HttpServletRequest request = this.getRequest();

		PrintWriter writer = this.getPrintWriter();

		String lcontent = request.getParameter("lcontent");
		String ltitle = request.getParameter("ltitle");
		
		
		
		HttpSession session = request.getSession();
		User uu = (User)session.getAttribute("qiantai");
		
		Liuyan bean = new  Liuyan();
		
		bean.setCtime(Util.getTime());
		bean.setLcontent(lcontent);
		bean.setLtitle(ltitle);
		bean.setStatus("未回复");
		bean.setUser(uu);
		
		
		liuyanDao.insertBean(bean);

		writer.print("<script language=javascript>alert('留言成功，等待管理员处理');window.location.href='indexmethod!liuyanlist';</script>");

	}
	
	
	//我的留言
	public String liuyanlist() throws Exception {

		HttpServletRequest request = this.getRequest();
		
		
		
		
		StringBuffer sb = new StringBuffer();
		sb.append(" where ");

		HttpSession session = request.getSession();
		User uu = (User)session.getAttribute("qiantai");
		
		sb.append("  user.id="+uu.getId()+" and  deletestatus=0   order by id desc ");
	
		
		String where = sb.toString();


		int currentpage = 1;
		int pagesize = 15;
		if (request.getParameter("pagenum") != null) {
			currentpage = Integer.parseInt(request.getParameter("pagenum"));
		}
		
		int total = liuyanDao.selectBeanCount(where.replaceAll("order by id desc", ""));
		
		request.setAttribute("liuyanlist", liuyanDao.selectBeanList((currentpage - 1)* pagesize, pagesize, where));
		
		request.setAttribute("pagerinfo", Pager.getPagerNormal(total, pagesize,currentpage, "indexmethod!liuyanlist", "共有" + total + "条记录"));

		request.setAttribute("title", "我的留言");
		
		this.setUrl("liuyanlist.jsp");
		return SUCCESS;
	}
	
	
	
	//删除操作
	public void liuyan3() throws IOException {
		HttpServletRequest request = this.getRequest();

		PrintWriter writer = this.getPrintWriter();

		
		
		Liuyan bean = liuyanDao.selectBean(" where id= "+request.getParameter("id"));
		
		
		bean.setDeletestatus(1);
		
		liuyanDao.updateBean(bean);

		writer.print("<script language=javascript>alert('操作成功');window.location.href='indexmethod!liuyanlist';</script>");

	}
	
	
	//跳转到查看留言页面
	public String liuyan4()  {
		HttpServletRequest request = this.getRequest();
		Liuyan bean = liuyanDao.selectBean(" where id= "+ request.getParameter("id"));
		request.setAttribute("bean", bean);
		request.setAttribute("title", "留言详情");

		this.setUrl("liuyan4.jsp");
		return SUCCESS;

	}
	
	
	public String gonggao()  {
		HttpServletRequest request = this.getRequest();
		Gonggao bean = gonggaoDao.selectBean(" where id= "+ request.getParameter("id"));
		request.setAttribute("bean", bean);
		request.setAttribute("title", "公告详情");

		this.setUrl("gonggao.jsp");
		return SUCCESS;

	}
}

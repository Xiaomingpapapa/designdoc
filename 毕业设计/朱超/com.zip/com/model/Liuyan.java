package com.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
//留言板
@Entity
@Table(name="t_Liuyan")
public class Liuyan {

	@Id
	@GeneratedValue
	private int id;//主键
	
	
	private int deletestatus;//是否删除的标志
	
	@ManyToOne
	@JoinColumn(name="userid")
	private User user;//关联的用户，外键
	
	private String ltitle;//留言标题
	

	
	@Column(name="lcontent", columnDefinition="TEXT")
	private String lcontent;//留言内容

	@Column(name="huifu", columnDefinition="TEXT")
	private String huifu;//回复内容
	
	
	private String status;//状态 未回复  已回复
	
	private String ctime;//留言时间
	
	private String htime;//回复时间


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public int getDeletestatus() {
		return deletestatus;
	}


	public void setDeletestatus(int deletestatus) {
		this.deletestatus = deletestatus;
	}


	public User getUser() {
		return user;
	}


	public void setUser(User user) {
		this.user = user;
	}


	public String getLtitle() {
		return ltitle;
	}


	public void setLtitle(String ltitle) {
		this.ltitle = ltitle;
	}


	public String getLcontent() {
		return lcontent;
	}


	public void setLcontent(String lcontent) {
		this.lcontent = lcontent;
	}


	public String getHuifu() {
		return huifu;
	}


	public void setHuifu(String huifu) {
		this.huifu = huifu;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public String getCtime() {
		return ctime;
	}


	public void setCtime(String ctime) {
		this.ctime = ctime;
	}


	public String getHtime() {
		return htime;
	}


	public void setHtime(String htime) {
		this.htime = htime;
	}
	
	
	
	
	
	
	
	
}

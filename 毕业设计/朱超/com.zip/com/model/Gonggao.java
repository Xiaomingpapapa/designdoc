package com.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
//公告
@Entity
@Table(name="t_Gonggao")
public class Gonggao {

	@Id
	@GeneratedValue
	private int id;//主键
	
	
	private int deletestatus;//是否删除的标志
	
	
	private String gbiaoti;//公告标题
	
	
	@Column(name="neirong", columnDefinition="TEXT")
	private String neirong;//公告内容
	

	private String shijian;//添加时间


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public int getDeletestatus() {
		return deletestatus;
	}


	public void setDeletestatus(int deletestatus) {
		this.deletestatus = deletestatus;
	}


	public String getGbiaoti() {
		return gbiaoti;
	}


	public void setGbiaoti(String gbiaoti) {
		this.gbiaoti = gbiaoti;
	}


	public String getNeirong() {
		return neirong;
	}


	public void setNeirong(String neirong) {
		this.neirong = neirong;
	}


	public String getShijian() {
		return shijian;
	}


	public void setShijian(String shijian) {
		this.shijian = shijian;
	}



	
	
	
	
}

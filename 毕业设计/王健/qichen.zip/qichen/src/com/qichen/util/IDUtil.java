package com.qichen.util;

import java.util.Random;

public class IDUtil {
	private final static long num =99999999999999999L;
	
	public static long getRandomId(){
		Random random = new Random(num);
		long l = random.nextLong();
		return l;
	}
}

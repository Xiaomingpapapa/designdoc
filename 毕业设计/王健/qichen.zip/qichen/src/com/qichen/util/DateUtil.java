package com.qichen.util;

import java.util.ArrayList;
import java.util.List;

public class DateUtil {

	private final static String [] months = new String []{"一月","二月","三月","四月","五月","六月","七月","八月","九月","十月","十一月","十二月"};
	
	public static Integer format(String month){
		int i = 1;
		for (int j = 0; j < months.length; j++) {
			String string = months[j];
			if(month.equals(string)){
				i=j+1;
			}
		}
		return i;
	}
	public static List<String> getMonths(int i){
		List<String> list = new ArrayList<>();
		for (int j = 0; j <=i; j++) {
			list.add(months[j]);
		}
		return list;
	}
}

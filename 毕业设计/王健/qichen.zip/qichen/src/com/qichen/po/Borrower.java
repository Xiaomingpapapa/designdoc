package com.qichen.po;

import java.io.Serializable;
import java.util.List;

import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection="Borrower")
public class Borrower implements Serializable{
    /**
	 * 
	 */
	private static final long serialVersionUID = -121421218784095422L;
	@Indexed
	private String borrowerid;
	@Indexed
    private String borrowername;
    
    private String address;
    @Indexed
    private Long borrowerphone;

    private String description;

    private String householdregister;

    private Long creditcardid;

    private List<String> orders;

    private List<String> collaterals;

    public String getBorrowerid() {
        return borrowerid;
    }

    public void setBorrowerid(String borrowerid) {
        this.borrowerid = borrowerid;
    }

    public String getBorrowername() {
        return borrowername;
    }

    public void setBorrowername(String borrowername) {
        this.borrowername = borrowername ;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Long getBorrowerphone() {
        return borrowerphone;
    }

    public void setBorrowerphone(Long borrowerphone) {
        this.borrowerphone = borrowerphone;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getHouseholdregister() {
        return householdregister;
    }

    public void setHouseholdregister(String householdregister) {
        this.householdregister = householdregister;
    }

    public Long getCreditcardid() {
        return creditcardid;
    }

    public void setCreditcardid(Long creditcardid) {
        this.creditcardid = creditcardid;
    }

	public Borrower() {
		super();
	}

	public List<String> getOrders() {
		return orders;
	}

	public void setOrders(List<String> orders) {
		this.orders = orders;
	}

	public List<String> getCollaterals() {
		return collaterals;
	}

	public void setCollaterals(List<String> collaterals) {
		this.collaterals = collaterals;
	}

	public Borrower(String borrowerid, String borrowername, String address, Long borrowerphone, String description,
			String householdregister, Long creditcardid, List<String> orders, List<String> collaterals) {
		super();
		this.borrowerid = borrowerid;
		this.borrowername = borrowername;
		this.address = address;
		this.borrowerphone = borrowerphone;
		this.description = description;
		this.householdregister = householdregister;
		this.creditcardid = creditcardid;
		this.orders = orders;
		this.collaterals = collaterals;
	}
	
}
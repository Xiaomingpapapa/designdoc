package com.qichen.po;

import java.io.Serializable;
import java.util.Date;

import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection="OrderSub")
/**
 * 需匹配订单
 * @author coco
 *
 */
public class OrderSub implements Serializable{


	/**
	 * 
	 */
	private static final long serialVersionUID = 1234657470632936600L;
	
	private String name;
	
	private String orderid;

    private Long account;

    private Integer term;
    
    private Double interest;
    //谁推送
    private String email;
    
	public OrderSub() {
	}

	public OrderSub(String orderid, String name,String email,Long account, Integer term, Double commission,Double interest, String description, Integer status) {
		this.orderid = orderid;
		this.account = account;
		this.term = term;
		this.commission = commission;
		this.description = description;
		this.status = status;
		this.interest=interest;
		this.email=email;
		this.name = name;
	}

	private Double commission;


    private String description;

    private Integer status;

    public String getOrderid() {
        return orderid;
    }

    public void setOrderid(String orderid) {
        this.orderid = orderid;
    }


    public Double getInterest() {
		return interest;
	}

	public void setInterest(Double interest) {
		this.interest = interest;
	}


    public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Long getAccount() {
        return account;
    }
    
    public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setAccount(Long account) {
        this.account = account;
    }

    public Integer getTerm() {
        return term;
    }

    public void setTerm(Integer term) {
        this.term = term;
    }

    public Double getCommission() {
        return commission;
    }

    public void setCommission(Double commission) {
        this.commission = commission;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description == null ? null : description.trim();
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }
}

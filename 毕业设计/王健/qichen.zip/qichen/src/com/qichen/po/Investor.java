package com.qichen.po;

import java.io.Serializable;
import java.util.List;

import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection="Investor")
public class Investor implements Serializable{
    /**
	 * 
	 */
	private static final long serialVersionUID = -2295474843640457627L;

	private String investorId;

    private String investorname;

    private Long investorphone;

    private String address;

    private String description;

    private Long accountofmoney;

    private Long creditcardid;

    private List<String> orders;

    public String getInvestorId() {
        return investorId;
    }

    public void setInvestorId(String investorId) {
        this.investorId = investorId;
    }


	public String getInvestorname() {
        return investorname;
    }

    public void setInvestorname(String investorname) {
        this.investorname = investorname;
    }

    public Long getInvestorphone() {
        return investorphone;
    }

    public void setInvestorphone(Long investorphone) {
        this.investorphone = investorphone;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Long getAccountofmoney() {
        return accountofmoney;
    }

    public void setAccountofmoney(Long accountofmoney) {
        this.accountofmoney = accountofmoney;
    }

    public Long getCreditcardid() {
        return creditcardid;
    }

    public void setCreditcardid(Long creditcardid) {
        this.creditcardid = creditcardid;
    }

	public List<String> getOrders() {
		return orders;
	}

	public void setOrders(List<String> orders) {
		this.orders = orders;
	}

	public Investor(String investorId, String investorname, Long investorphone, String address, String description,
			Long accountofmoney, Long creditcardid, List<String> orders) {
		super();
		this.investorId = investorId;
		this.investorname = investorname;
		this.investorphone = investorphone;
		this.address = address;
		this.description = description;
		this.accountofmoney = accountofmoney;
		this.creditcardid = creditcardid;
		this.orders = orders;
	}

	public Investor() {
		super();
		// TODO Auto-generated constructor stub
	}
    
}
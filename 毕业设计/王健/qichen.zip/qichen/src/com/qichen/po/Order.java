package com.qichen.po;

import java.io.Serializable;
import java.util.Date;

import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection="Order")
/*
 * 注解 映射mongodb 数据库表
 */
public class Order implements Serializable{
    /**
	 * 
	 */
	private static final long serialVersionUID = -7390108640855331921L;

	private String orderid;

    private Long account;

    private Date signingdate;
    
    private Date loandate;
    
    private Double interest;
    
    private Integer term;

    public Order(String orderid, Date signingdate, Date loandate,Double interest, Long account, Integer term, Double commission,
			Double rebate, String description, Integer status) {
		super();
		this.orderid = orderid;
		this.account = account;
		this.term = term;
		this.loandate=loandate;
		this.signingdate=signingdate;
		this.commission = commission;
		this.rebate = rebate;
		this.description = description;
		this.status = status;
		this.interest=interest;
	}

	public Order() {
		// TODO Auto-generated constructor stub
	}

	public Order(String orderid, Long account, Integer term, Double commission, Double interest,String description, Integer status) {
		this.orderid = orderid;
		this.account = account;
		this.term = term;
		this.commission = commission;
		this.description = description;
		this.status = status;
		this.interest=interest;
	}

	public Double getInterest() {
		return interest;
	}

	public void setInterest(Double interest) {
		this.interest = interest;
	}

	private Double commission;

    private Double rebate;

    private String description;

    private Integer status;

    public String getOrderid() {
        return orderid;
    }

    public void setOrderid(String orderid) {
        this.orderid = orderid;
    }

    public Date getSigningdate() {
        return signingdate;
    }

    public void setSigningdate(Date signingdate) {
        this.signingdate = signingdate;
    }

    public Date getLoandate() {
        return loandate;
    }

    public void setLoandate(Date loandate) {
        this.loandate = loandate;
    }

    public Long getAccount() {
        return account;
    }

    public void setAccount(Long account) {
        this.account = account;
    }

    public Integer getTerm() {
        return term;
    }

    public void setTerm(Integer term) {
        this.term = term;
    }

    public Double getCommission() {
        return commission;
    }

    public void setCommission(Double commission) {
        this.commission = commission;
    }

    public Double getRebate() {
        return rebate;
    }

    public void setRebate(Double rebate) {
        this.rebate = rebate ;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }
}
package com.qichen.po;

import java.io.Serializable;
import java.util.Date;

import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection="Plan")
public class Plan implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 8035537745253821862L;
	
	private String id;

	private String title;
	
	private Date date;
	
	private String  email;
	
	private String description;
	
	private Integer status;

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getDescription() {
		return description;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public Plan() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Plan(String id,String title, Date date, String email, String description, Integer status) {
		super();
		this.id=id;
		this.title = title;
		this.date = date;
		this.email = email;
		this.description = description;
		this.status = status;
	}
	
	
}

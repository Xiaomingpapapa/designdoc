package com.qichen.po;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection="Staff")
public class Staff implements Serializable{
    /**
	 * 
	 */
	private static final long serialVersionUID = -3003917618665532330L;

	@Indexed
	private String email;

    private String password;
    @Indexed
    private String name;

    private Long telephone;

    private Date starttime;
	
    private Map<Date, Double> salary;

    private Map<String,String> investors;
    
    private Map<String,String> borrowers;
    
    private List<String> orders ;
    
    private Long deptId;
    
    public Staff() {
		super();
		// TODO Auto-generated constructor stub
	}

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email ;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password ;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Long getTelephone() {
        return telephone;
    }

    public void setTelephone(Long telephone) {
        this.telephone = telephone;
    }

    public Date getStarttime() {
        return starttime;
    }

    public void setStarttime(Date starttime) {
        this.starttime = starttime;
    }


    public Map<Date, Double> getSalary() {
        return salary;
    }

    public void setSalary(Map<Date, Double> salary) {
        this.salary = salary;
    }
    

	public Map<String, String> getInvestors() {
		return investors;
	}

	public void setInvestors(Map<String, String> investors) {
		this.investors = investors;
	}

	public Map<String, String> getBorrowers() {
		return borrowers;
	}

	public void setBorrowers(Map<String, String> borrowers) {
		this.borrowers = borrowers;
	}

	public List<String> getOrders() {
		return orders;
	}

	public Staff(String email, String password, String name, Long telephone, Date starttime, Map<Date, Double> salary,
			Map<String, String> investors, Map<String, String> borrowers, List<String> orders, Long deptId) {
		super();
		this.email = email;
		this.password = password;
		this.name = name;
		this.telephone = telephone;
		this.starttime = starttime;
		this.salary = salary;
		this.investors = investors;
		this.borrowers = borrowers;
		this.orders = orders;
		this.deptId = deptId;
	}

	public void setOrders(List<String> orders) {
		this.orders = orders;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public Long getDeptId() {
        return deptId;
    }

    public void setDeptId(Long deptId) {
        this.deptId = deptId;
    }
}
package com.qichen.po;

import java.io.Serializable;

import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection="Dept")
public class Dept implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 6277892113502099113L;

	@Indexed
	private Long deptid;

    private String deptname;

    public Dept(Long deptid,String deptname) {
    	this.deptid = deptid;
    	this.deptname = deptname;
	}
    
    @Override
	public String toString() {
		return "Dept [deptid=" + deptid + ", deptname=" + deptname + "]";
	}

	public Dept() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Long getDeptid() {
        return deptid;
    }

    public void setDeptid(Long deptid) {
        this.deptid = deptid;
    }

    public String getDeptname() {
        return deptname;
    }

    public void setDeptname(String deptname) {
        this.deptname = deptname == null ? null : deptname.trim();
    }
}
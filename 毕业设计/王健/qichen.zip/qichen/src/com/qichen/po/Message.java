package com.qichen.po;

import java.io.Serializable;
import java.util.Date;

import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import com.sun.xml.internal.bind.v2.runtime.Name;
/**
 * 离线消息
 * @author coco
 *
 */
@Document(collection="Message")
public class Message implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 5543307960325496624L;
	
	private String title;
	@Indexed
	private String sendEmail;
	@Indexed
	private String sendToEmail;
	
	private Date date ;
	
	private String description;
	
	private Boolean status;

	
	
	public Message(String title, String sendEmail, String sendToEmail, Date date, String description,Boolean status) {
		this.title = title;
		this.sendEmail = sendEmail;
		this.sendToEmail = sendToEmail;
		this.date = date;
		this.description = description;
		this.status = status;
	}


	public Message() {
		// TODO Auto-generated constructor stub
	}

	public String getSendEmail() {
		return sendEmail;
	}

	public Boolean getStatus() {
		return status;
	}


	public void setStatus(Boolean status) {
		this.status = status;
	}


	public void setSendEmail(String sendEmail) {
		this.sendEmail = sendEmail;
	}

	public String getSendToEmail() {
		return sendToEmail;
	}

	public void setSendToEmail(String sendToEmail) {
		this.sendToEmail = sendToEmail;
	}

	public Date getDate() {
		return date;
	}

	public String getTitle() {
		return title;
	}


	public void setTitle(String title) {
		this.title = title;
	}


	public void setDate(Date date) {
		this.date = date;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	
	
}

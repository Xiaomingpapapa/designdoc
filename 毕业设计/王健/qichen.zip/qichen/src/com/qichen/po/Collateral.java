package com.qichen.po;

import java.io.Serializable;
import java.math.BigDecimal;

import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection="Collateral")
public class Collateral implements Serializable{
    /**
	 * 
	 */
	private static final long serialVersionUID = 562866024448650141L;

	private String collateralid;

    private Integer collateralvalue;

    private String address;

    private BigDecimal area;

    private Integer agelimit;

    public String getCollateralid() {
        return collateralid;
    }

    public void setCollateralid(String collateralid) {
        this.collateralid = collateralid;
    }

    public Integer getCollateralvalue() {
        return collateralvalue;
    }

    public void setCollateralvalue(Integer collateralvalue) {
        this.collateralvalue = collateralvalue;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address ;
    }

    public BigDecimal getArea() {
        return area;
    }

    public void setArea(BigDecimal area) {
        this.area = area;
    }

    public Integer getAgelimit() {
        return agelimit;
    }

    public void setAgelimit(Integer agelimit) {
        this.agelimit = agelimit;
    }
}
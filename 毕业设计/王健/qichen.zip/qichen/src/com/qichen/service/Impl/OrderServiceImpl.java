package com.qichen.service.Impl;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.hamcrest.core.Is;
import org.junit.Test;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.qichen.po.Borrower;
import com.qichen.po.Investor;
import com.qichen.po.Order;
import com.qichen.po.OrderSub;
import com.qichen.po.Staff;
import com.qichen.service.OrderService;
import com.qichen.util.DateUtil;

@Service
public class OrderServiceImpl implements OrderService{

	private static final Logger log = Logger.getLogger(OrderServiceImpl.class);
	@Resource
	private MongoTemplate mongoTemplate;
	@Override
	public void addOrder(Order order) {
		if(log.isInfoEnabled()){
			log.info("Enter method addOrder success");
		}
		mongoTemplate.insert(order,"Order");
		if(log.isInfoEnabled()){
			log.info("Leave method addOrder success");
		}
	}
	@Override
	public void pushOrderSub(OrderSub sub) {
		if(log.isInfoEnabled()){
			log.info("Enter method pushOrderSub success");
		}
		mongoTemplate.insert(sub,"OrderSub");
		if(log.isInfoEnabled()){
			log.info("Leave method pushOrderSub success");
		}
	}
	@Override
	public Order findOrderById(String id) {
		if(log.isInfoEnabled()){
			log.info("Enter method findOrderById success");
		}
		Order order = mongoTemplate.findOne(new Query(Criteria.where("orderid").is(id)),Order.class, "Order");
		if(log.isInfoEnabled()){
			log.info("Leave method findOrderById success");
		}
		return order;
	}
	@Override
	public List<OrderSub> findAll() {
		if(log.isInfoEnabled()){
			log.info("Enter method findAll success");
		}
		List<OrderSub> list = mongoTemplate.findAll(OrderSub.class,"OrderSub");
		if(list==null){
			list=new ArrayList<>();
		}
		if(log.isInfoEnabled()){
			log.info("Leave method findAll success");
		}
		return list;
	}
	@Override
	public List<Order> findALLOrderToDeal(List<String> orders) {
		if(log.isInfoEnabled()){
			log.info("Enter method findALLOrderToDeal success");
		}
		List<Order> list = new ArrayList<>();
		if(orders.size()==0)return list;
		for (String string : orders) {
			 Order order = mongoTemplate.findOne(new Query(Criteria.where("orderid").is(string)), Order.class);
			 if(order.getStatus()!=4){
				 list.add(order);
			 }
		}
		if(log.isInfoEnabled()){
			log.info("Leave method findALLOrderToDeal success");
		}
		return list;
	}
	@Override
	public void changeOrder(Order order) {
		if(log.isInfoEnabled()){
			log.info("Enter method changeOrder success");
		}
		mongoTemplate.remove(new Query(Criteria.where("orderid").is(order.getOrderid())), Order.class, "Order");
		mongoTemplate.insert(order, "Order");
		if(log.isInfoEnabled()){
			log.info("Leave method changeOrder success");
		}
	}
	@Override
	public void commitOrder(String id, String signingdate, String loandate) {
		if(log.isInfoEnabled()){
			log.info("Enter method commitOrder success");
		}
		String[] split = signingdate.split("-");
		Integer month = DateUtil.format(split[1]);
		if(month<10){
			signingdate =split[0]+"-0"+month+"-"+split[2];
		}else{
			signingdate =split[0]+"-"+month+"-"+split[2];
		}
		String[] strings = loandate.split("-");
		Integer format = DateUtil.format(strings[1]);
		if(format<10){
			loandate=strings[0]+"-0"+format+"-"+strings[2];
		}else{
			loandate=strings[0]+"-"+format+"-"+strings[2];
		}
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
		try {
			Date date1 = simpleDateFormat.parse(signingdate);
			Date date2 = simpleDateFormat.parse(loandate);
			System.out.println(date1);
			mongoTemplate.upsert(new Query(Criteria.where("orderid").is(id)), new Update().set("signingdate", date1), Order.class);
			mongoTemplate.upsert(new Query(Criteria.where("orderid").is(id)), new Update().set("loandate", date2), Order.class);
			mongoTemplate.upsert(new Query(Criteria.where("orderid").is(id)), new Update().set("status", 3), Order.class);

		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@Override
	public Boolean removeOrder(String id) {
		if(log.isInfoEnabled()){
			log.info("Enter method removeOrder success");
		}
		Order order = mongoTemplate.findOne(new Query(Criteria.where("orderid").is(id)), Order.class);
		if(order.getStatus()<3){
			mongoTemplate.remove(new Query(Criteria.where("orderid").is(id)), Order.class);
			List<Staff> list = mongoTemplate.find(new Query(Criteria.where("orders").in(id)), Staff.class, "Staff");
			Investor investor = mongoTemplate.findOne(new Query(Criteria.where("orders").in(id)), Investor.class, "Investor");
			if(investor!=null){
				List<String> orders = investor.getOrders();
				Iterator<String> iterator = orders.iterator();
				while (iterator.hasNext()) {
					String string = (String) iterator.next();
					if(string.equals(id)){
					iterator.remove();
					}
					
				}
				mongoTemplate.upsert(new Query(Criteria.where("investorid").is(investor.getInvestorId())), new Update().set("orders", orders), Investor.class);
			}
			Borrower borrower = mongoTemplate.findOne(new Query(Criteria.where("orders").in(id)), Borrower.class);
				List<String> o = borrower.getOrders();
				Iterator<String> it = o.iterator();
				while (it.hasNext()) {
					String string = (String) it.next();
					if(string.equals(id)){
					it.remove();
					}
					
				}
				mongoTemplate.upsert(new Query(Criteria.where("borrowerid").is(borrower.getBorrowerid())), new Update().set("orders",o), Borrower.class);
			for (Staff staff : list) {
				List<String> orders = staff.getOrders();
				Iterator<String> iterator = orders.iterator();
				while (iterator.hasNext()) {
					String string = (String) iterator.next();
					if(string.equals(id)){
						iterator.remove();
					}
				}
				mongoTemplate.upsert(new Query(Criteria.where("email").is(staff.getEmail())), new Update().set("orders", orders), Staff.class);
			}if(log.isInfoEnabled()){
				log.info("Leave method removeOrder success");
			}
			return true;
		}else{
			if(log.isInfoEnabled()){
				log.info("Leave method removeOrder success");
			}
			return false;
		}
		
		
	}
	@Override
	public List<Order> getDealOrders(String email) {
		if(log.isInfoEnabled()){
			log.info("Enter method getDealOrders success");
		}
		Staff staff = mongoTemplate.findOne(new Query(Criteria.where("email").is(email)), Staff.class, "Staff");
		List<Order> orders = new ArrayList<>();
		if (staff.getDeptId()==0L) {
			orders = mongoTemplate.find(new Query(Criteria.where("status").gte(4)),Order.class);
		}else{
			List<String> list = staff.getOrders();
				if(list==null){
					return orders;
				}
			orders = mongoTemplate.find(new Query(Criteria.where("orderid").in(list).and("status").gte(4)), Order.class,"Order");
			}
		if(log.isInfoEnabled()){
			log.info("Leave method getDealOrders success");
		}
		return orders;
	}
	@Override
	public List<Order> getWaitToDealOrders(String email) {
		if(log.isInfoEnabled()){
			log.info("Enter method getWaitToDealOrders success");
		}
		List<Order> orders = new ArrayList<>();
		Staff staff = mongoTemplate.findOne(new Query(Criteria.where("email").is(email)),Staff.class);
		if(staff.getDeptId()!=0L){
			return orders;
		}
		List<Order> find = mongoTemplate.find(new Query(Criteria.where("status").is(3L)), Order.class, "Order");
		if(find==null){
			return orders;
		}else{
			return find;
		}
	}
	@Override
	public void removeOrderSub(String orderid) {
		if(log.isInfoEnabled()){
			log.info("Enter method removeOrderSub success");
		}
		mongoTemplate.remove(new Query(Criteria.where("orderid").is(orderid)), OrderSub.class);
		if(log.isInfoEnabled()){
			log.info("Leave method removeOrderSub success");
		}
	}
	@Override
	@Test
	public List<Order> getOrderToPayInterest(String email) {
		if(log.isInfoEnabled()){
			log.info("Enter method getOrderToPayInterestList success");
		}
		List<Order> orders = new ArrayList<>();
		
		Staff staff = mongoTemplate.findOne(new Query(Criteria.where("email").is(email)), Staff.class,"Staff");
		if(staff.getDeptId()==0L||staff.getDeptId()==1000L){
			for (int i = 24; i >= 0; i--) {
				Calendar calendar = Calendar.getInstance();
			    Date date = new Date(System.currentTimeMillis());
			    calendar.setTime(date);
			    calendar.add(Calendar.WEEK_OF_YEAR, +1);
			    calendar.add(Calendar.MONTH, -i);
			    calendar.set(Calendar.HOUR_OF_DAY, 16);
			    calendar.set(Calendar.SECOND,0);
			    calendar.set(Calendar.MINUTE,0);
			    date = calendar.getTime();
			    Date date2 = new Date(System.currentTimeMillis());
			    calendar.setTime(date2);
			    calendar.add(Calendar.MONTH, -i);
			    calendar.set(Calendar.HOUR_OF_DAY, 16);
			    calendar.set(Calendar.SECOND,0);
			    calendar.set(Calendar.MINUTE,0);
			    date2 = calendar.getTime();
			    List<Order> find = mongoTemplate.find(new Query(Criteria.where("signingdate").lte(date).gte(date2).and("status").is(4)), Order.class, "Order");
			    if(find!=null){
			    	for (Order order : find) {
						orders.add(order);
					}
			    }
			}
			}else{
		List<String> list = staff.getOrders();
		if(list==null){
			return orders;
		}else{
			for (String string : list) {
				for (int i = 24; i >= 0; i--) {
					Calendar calendar = Calendar.getInstance();
				    Date date = new Date(System.currentTimeMillis());
				    calendar.setTime(date);
				    calendar.add(Calendar.WEEK_OF_YEAR, +1);
				    calendar.add(Calendar.MONTH, -i);
				    calendar.set(Calendar.HOUR_OF_DAY, 16);
				    calendar.set(Calendar.SECOND,0);
				    calendar.set(Calendar.MINUTE,0);
				    date = calendar.getTime();
				    Date date2 = new Date(System.currentTimeMillis());
				    calendar.setTime(date2);
				    calendar.add(Calendar.MONTH, -i);
				    calendar.set(Calendar.HOUR_OF_DAY, 16);
				    calendar.set(Calendar.SECOND,0);
				    calendar.set(Calendar.MINUTE,0);
				    date2 = calendar.getTime();
				    Order order = mongoTemplate.findOne(new Query(Criteria.where("orderid").is(string).and("status").is(4).andOperator(Criteria.where("signingdate").lte(date).gte(date2))), Order.class, "Order");
				    if(order!=null){
				    orders.add(order);
				    }
				}
				}
		
		}
		}
		if(log.isInfoEnabled()){
			log.info("Leave method getOrderToPayInterestList success");
		}
		return orders;
	}
	@Override
	public List<Order> getAllOrderToPayInterest() {
		if(log.isInfoEnabled()){
			log.info("Enter method getAllOrderToPayInterest success");
		}
			List<Order> orders = new ArrayList<>();
			for (int i = 24; i >= 0; i--) {
				Calendar calendar = Calendar.getInstance();
			    Date date = new Date(System.currentTimeMillis());
			    calendar.setTime(date);
			    calendar.add(Calendar.WEEK_OF_YEAR, +1);
			    calendar.add(Calendar.MONTH, -i);
			    calendar.set(Calendar.HOUR_OF_DAY, 16);
			    calendar.set(Calendar.SECOND,0);
			    calendar.set(Calendar.MINUTE,0);
			    date = calendar.getTime();
			    Date date2 = new Date(System.currentTimeMillis());
			    calendar.setTime(date2);
			    calendar.add(Calendar.MONTH, -i);
			    calendar.set(Calendar.HOUR_OF_DAY, 16);
			    calendar.set(Calendar.SECOND,0);
			    calendar.set(Calendar.MINUTE,0);
			    date2 = calendar.getTime();
			    Order order = mongoTemplate.findOne(new Query(Criteria.where("status").is(4).andOperator(Criteria.where("signingdate").lte(date).gte(date2))), Order.class, "Order");
			    if(order!=null){
			    orders.add(order);
			}
			}
			if(log.isInfoEnabled()){
				log.info("Leave method getAllOrderToPayInterest success");
			}
		return orders;
	}
	@Override
	public List<Long> getPerformanceOfMonth(String email,int lastyear) {
		if(log.isInfoEnabled()){
			log.info("Enter method getPerformanceOfMonth success");
		}
		List<Long> list = new ArrayList<>();
		Staff staff = mongoTemplate.findOne(new Query(Criteria.where("email").is(email)), Staff.class);
		if(staff.getDeptId()==0L){
			Calendar cale = Calendar.getInstance();
		    Date date = new Date(System.currentTimeMillis());
		    cale.setTime(date);
		    int i = cale.get(Calendar.MONTH);
		    Date date1 = new Date();
			Date date2 = new Date();
		    for(int j =i;j>=0;j--){
		    	Long account =0L;
		    	 cale = Calendar.getInstance();  
		    	 cale.add(Calendar.YEAR, lastyear);
			     cale.add(Calendar.MONTH, -j+1);  
			     cale.set(Calendar.DAY_OF_MONTH, 1);  
			     cale.set(Calendar.HOUR_OF_DAY, 0);
			     cale.set(Calendar.SECOND,0);
			     cale.set(Calendar.MINUTE,0);
			     date1=cale.getTime();
			     // 获取后一月的第一天  
			     cale = Calendar.getInstance();  
			     cale.add(Calendar.YEAR, lastyear);
			     cale.add(Calendar.MONTH, -j);  
			     cale.set(Calendar.DAY_OF_MONTH, 1);  
			     cale.set(Calendar.HOUR_OF_DAY, 0);
			     cale.set(Calendar.SECOND,0);
			     cale.set(Calendar.MINUTE,0);
			     date2=cale.getTime();
			     List<Order> list2 = mongoTemplate.find(new Query(Criteria.where("signingdate").lte(date1).gte(date2).and("status").gte(4)), Order.class);
			     if(list2==null){
			    	 continue;
			     }else {
					for (int k = 0; k < list2.size(); k++) {
						account+=list2.get(k).getAccount();
					}
				}
			     list.add(account);
		    }
		}else{
		List<String> orders = staff.getOrders();
		if(orders==null){
			return list;
		}
		Calendar cale = Calendar.getInstance();
	    Date date = new Date(System.currentTimeMillis());
	    cale.setTime(date);
	    int i = cale.get(Calendar.MONTH);
	    Date date1 = new Date();
		Date date2 = new Date();
	    for(int j =i;j>=0;j--){
	    	Long account =0L;
	    	 cale = Calendar.getInstance();  
	    	 cale.add(Calendar.YEAR, lastyear);
		     cale.add(Calendar.MONTH, -j+1);  
		     cale.set(Calendar.DAY_OF_MONTH, 1);  
		     cale.set(Calendar.HOUR_OF_DAY, 0);
		     cale.set(Calendar.SECOND,0);
		     cale.set(Calendar.MINUTE,0);
		     date1=cale.getTime();
		     // 获取后一月的第一天  
		     cale = Calendar.getInstance();  
		     cale.add(Calendar.YEAR, lastyear);
		     cale.add(Calendar.MONTH, -j);  
		     cale.set(Calendar.DAY_OF_MONTH, 1);  
		     cale.set(Calendar.HOUR_OF_DAY, 0);
		     cale.set(Calendar.SECOND,0);
		     cale.set(Calendar.MINUTE,0);
		     date2=cale.getTime();
		     List<Order> list2 = mongoTemplate.find(new Query(Criteria.where("orderid").in(orders).andOperator(Criteria.where("signingdate").lte(date1).gte(date2).and("status").gte(4))), Order.class);
		     if(list2==null){
		    	 continue;
		     }else {
				for (int k = 0; k < list2.size(); k++) {
					account+=list2.get(k).getAccount();
				}
			}
		     list.add(account);
	    }
		}
	    if(log.isInfoEnabled()){
			log.info("Leave method getPerformanceOfMonth success");
		}
		return list;
	}
	@Override
	public Double getPercentOfAccount(String email) {
		if(log.isInfoEnabled()){
			log.info("Enter method getPercentOfAccount success");
		}
		List<Long> list = new ArrayList<>();
		Staff staff = mongoTemplate.findOne(new Query(Criteria.where("email").is(email)), Staff.class);
		Calendar cale = Calendar.getInstance();
	    Date date = new Date(System.currentTimeMillis());
	    cale.setTime(date);
	    Date date1 = new Date();
		Date date2 = new Date();
		if(staff.getDeptId()==0L){
			for(int j =1;j>=0;j--){
		    	Long account =0L;
		    	 cale = Calendar.getInstance();  
			     cale.add(Calendar.MONTH, -j+1);  
			     cale.set(Calendar.DAY_OF_MONTH, 1);  
			     cale.set(Calendar.HOUR_OF_DAY, 0);
			     cale.set(Calendar.SECOND,0);
			     cale.set(Calendar.MINUTE,0);
			     date1=cale.getTime();
			     // 获取后一月的第一天  
			     cale = Calendar.getInstance();  
			     cale.add(Calendar.MONTH, -j);  
			     cale.set(Calendar.DAY_OF_MONTH, 1);  
			     cale.set(Calendar.HOUR_OF_DAY, 0);
			     cale.set(Calendar.SECOND,0);
			     cale.set(Calendar.MINUTE,0);
			     date2=cale.getTime();
			     List<Order> list2 = mongoTemplate.find(new Query(Criteria.where("signingdate").lte(date1).gte(date2).and("status").gte(4)), Order.class);
			     if(list2==null){
			    	 continue;
			     }else {
					for (int k = 0; k < list2.size(); k++) {
						account+=list2.get(k).getAccount();
					}
				}
			     list.add(account);
			}
		}else{
			List<String> orders = staff.getOrders();
			if(orders==null){
				return 0D;
			}
		    for(int j =1;j>=0;j--){
		    	Long account =0L;
		    	 cale = Calendar.getInstance();  
			     cale.add(Calendar.MONTH, -j+1);  
			     cale.set(Calendar.DAY_OF_MONTH, 1);  
			     cale.set(Calendar.HOUR_OF_DAY, 0);
			     cale.set(Calendar.SECOND,0);
			     cale.set(Calendar.MINUTE,0);
			     date1=cale.getTime();
			     // 获取后一月的第一天  
			     cale = Calendar.getInstance();  
			     cale.add(Calendar.MONTH, -j);  
			     cale.set(Calendar.DAY_OF_MONTH, 1);  
			     cale.set(Calendar.HOUR_OF_DAY, 0);
			     cale.set(Calendar.SECOND,0);
			     cale.set(Calendar.MINUTE,0);
			     date2=cale.getTime();
			     List<Order> list2 = mongoTemplate.find(new Query(Criteria.where("orderid").in(orders).andOperator(Criteria.where("signingdate").lte(date1).gte(date2)).and("status").gte(4)), Order.class);
			     if(list2==null){
			    	 continue;
			     }else {
					for (int k = 0; k < list2.size(); k++) {
						account+=list2.get(k).getAccount();
					}
				}
			     list.add(account);
		    }
		}
		double l =Double.longBitsToDouble(list.get(1));
		double s =Double.longBitsToDouble(list.get(0));
		double percent=0D;
		if (s==0D) {
			s=1L;
			percent=(l/s);		
		}else{
			percent=(l/s);	
		}
		BigDecimal bigDecimal = new BigDecimal(percent);
		double doubleValue = bigDecimal.setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue();
		if(log.isInfoEnabled()){
			log.info("Leave method getPercentOfAccount success");
		}
		return doubleValue;
	}
	@Override
	public Double getPercentOfNum(String email) {
		if(log.isInfoEnabled()){
			log.info("Enter method getPercentOfNum success");
		}
		List<Long> list = new ArrayList<>();
		Staff staff = mongoTemplate.findOne(new Query(Criteria.where("email").is(email)), Staff.class);
		Calendar cale = Calendar.getInstance();
	    Date date = new Date(System.currentTimeMillis());
	    cale.setTime(date);
	    Date date1 = new Date();
		Date date2 = new Date();
		if(staff.getDeptId()==0L){
			for(int j =1;j>=0;j--){
		    	 cale = Calendar.getInstance();  
			     cale.add(Calendar.MONTH, -j+1);  
			     cale.set(Calendar.DAY_OF_MONTH, 1);  
			     cale.set(Calendar.HOUR_OF_DAY, 0);
			     cale.set(Calendar.SECOND,0);
			     cale.set(Calendar.MINUTE,0);
			     date1=cale.getTime();
			     // 获取后一月的第一天  
			     cale = Calendar.getInstance();  
			     cale.add(Calendar.MONTH, -j);  
			     cale.set(Calendar.DAY_OF_MONTH, 1);  
			     cale.set(Calendar.HOUR_OF_DAY, 0);
			     cale.set(Calendar.SECOND,0);
			     cale.set(Calendar.MINUTE,0);
			     date2=cale.getTime();
			     long count = mongoTemplate.count(new Query(Criteria.where("signingdate").lte(date1).gte(date2).and("status").gte(4)), Order.class, "Order");
			     list.add(count);
			}
		}else{
			List<String> orders = staff.getOrders();
			if(orders==null){
				return 0D;
			}
		    for(int j =1;j>=0;j--){
		    	 cale = Calendar.getInstance();  
			     cale.add(Calendar.MONTH, -j+1);  
			     cale.set(Calendar.DAY_OF_MONTH, 1);  
			     cale.set(Calendar.HOUR_OF_DAY, 0);
			     cale.set(Calendar.SECOND,0);
			     cale.set(Calendar.MINUTE,0);
			     date1=cale.getTime();
			     // 获取后一月的第一天  
			     cale = Calendar.getInstance();  
			     cale.add(Calendar.MONTH, -j);  
			     cale.set(Calendar.DAY_OF_MONTH, 1);  
			     cale.set(Calendar.HOUR_OF_DAY, 0);
			     cale.set(Calendar.SECOND,0);
			     cale.set(Calendar.MINUTE,0);
			     date2=cale.getTime();
			     long count = mongoTemplate.count(new Query(Criteria.where("orderid").in(orders).andOperator(Criteria.where("signingdate").lte(date1).gte(date2).and("status").gte(4))), Order.class);
			     list.add(count);
		    }
		}
		double l =Double.longBitsToDouble(list.get(1));
		double s =Double.longBitsToDouble(list.get(0));
		double percent=0D;
		if (s==0D) {
			s=1L;
			percent=(l/s);		
		}else{
			percent=(l/s);	
		}
		BigDecimal bigDecimal = new BigDecimal(percent);
		double doubleValue = bigDecimal.setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue();
		if(log.isInfoEnabled()){
			log.info("Leave method getPercentOfNum success");
		}
		return doubleValue;
	}
	@Override
	public List<Long> getOrderCountOfMonth(String email, int lastyear) {
		if(log.isInfoEnabled()){
			log.info("Enter method getOrderCountOfMonth success");
		}
		List<Long> list = new ArrayList<>();
		Staff staff = mongoTemplate.findOne(new Query(Criteria.where("email").is(email)), Staff.class);
		if(staff.getDeptId()==0L){
			Calendar cale = Calendar.getInstance();
		    Date date = new Date(System.currentTimeMillis());
		    cale.setTime(date);
		    int i = cale.get(Calendar.MONTH);
		    Date date1 = new Date();
			Date date2 = new Date();
		    for(int j =i;j>=0;j--){
		    	 cale = Calendar.getInstance();  
		    	 cale.add(Calendar.YEAR, lastyear);
			     cale.add(Calendar.MONTH, -j+1);  
			     cale.set(Calendar.DAY_OF_MONTH, 1);  
			     cale.set(Calendar.HOUR_OF_DAY, 0);
			     cale.set(Calendar.SECOND,0);
			     cale.set(Calendar.MINUTE,0);
			     date1=cale.getTime();
			     // 获取后一月的第一天  
			     cale = Calendar.getInstance();  
			     cale.add(Calendar.YEAR, lastyear);
			     cale.add(Calendar.MONTH, -j);  
			     cale.set(Calendar.DAY_OF_MONTH, 1);  
			     cale.set(Calendar.HOUR_OF_DAY, 0);
			     cale.set(Calendar.SECOND,0);
			     cale.set(Calendar.MINUTE,0);
			     date2=cale.getTime();
			    long count = mongoTemplate.count(new Query(Criteria.where("signingdate").lte(date1).gte(date2).and("status").gte(4)),Order.class);
			    list.add(count);
		    }
		}
		    else {
		    	List<String> orders = staff.getOrders();
				if(orders==null){
					return list;
				}
				Calendar cale = Calendar.getInstance();
			    Date date = new Date(System.currentTimeMillis());
			    cale.setTime(date);
			    int i = cale.get(Calendar.MONTH);
			    Date date1 = new Date();
				Date date2 = new Date();
			    for(int j =i;j>=0;j--){
			    	 cale = Calendar.getInstance();  
			    	 cale.add(Calendar.YEAR, lastyear);
				     cale.add(Calendar.MONTH, -j+1);  
				     cale.set(Calendar.DAY_OF_MONTH, 1);  
				     cale.set(Calendar.HOUR_OF_DAY, 0);
				     cale.set(Calendar.SECOND,0);
				     cale.set(Calendar.MINUTE,0);
				     date1=cale.getTime();
				     // 获取后一月的第一天  
				     cale = Calendar.getInstance();  
				     cale.add(Calendar.YEAR, lastyear);
				     cale.add(Calendar.MONTH, -j);  
				     cale.set(Calendar.DAY_OF_MONTH, 1);  
				     cale.set(Calendar.HOUR_OF_DAY, 0);
				     cale.set(Calendar.SECOND,0);
				     cale.set(Calendar.MINUTE,0);
				     date2=cale.getTime();
				     long count = mongoTemplate.count(new Query(Criteria.where("signingdate").lte(date1).gte(date2).andOperator(Criteria.where("orderid").in(orders).and("status").gte(4))), Order.class);
				     list.add(count);
			    }
			}
		if(log.isInfoEnabled()){
			log.info("Leave method getOrderCountOfMonth success");
		}
		return list;
	}
	@Override
	public JSONObject getOrdersBorrowersInfo(List<String> list) {
		if(log.isInfoEnabled()){
			log.info("Enter method getOrdersBorrowersInfo success");
		}
		JSONObject jsonObject = new JSONObject();
		for (String string : list) {
			Borrower borrower = mongoTemplate.findOne(new Query(Criteria.where("orders").is(string)), Borrower.class);
			jsonObject.put(string, borrower);
		}
		if(log.isInfoEnabled()){
			log.info("Leave method getOrdersBorrowersInfo success");
		}
		return jsonObject;
	}
	
	public JSONObject getOrdersInvestorsInfo(List<String> list){
		if(log.isInfoEnabled()){
			log.info("Enter method getOrdersInvestorsInfo success");
		}
		JSONObject jsonObject = new JSONObject();
		for (String string : list) {
			Investor investor = mongoTemplate.findOne(new Query(Criteria.where("orders").is(string)), Investor.class);
			jsonObject.put(string, investor);
		}
		if(log.isInfoEnabled()){
			log.info("Leave method getOrdersInvestorsInfo success");
		}
		return jsonObject;
		
	}
	@Override
	public JSONObject getOrderAboutInfos(String orderid) {
		if(log.isInfoEnabled()){
			log.info("Enter method getOrderAboutInfos success");
		}
		JSONObject jsonObject = new JSONObject();
		Order order = mongoTemplate.findOne(new Query(Criteria.where("orderid").is(orderid)), Order.class);
		Borrower borrower = mongoTemplate.findOne(new Query(Criteria.where("orders").is(orderid)), Borrower.class);
		Investor investor = mongoTemplate.findOne(new Query(Criteria.where("orders").is(orderid)), Investor.class);
		List<Staff> list = mongoTemplate.find(new Query(Criteria.where("orders").is(orderid)), Staff.class);
		jsonObject.put("order", order);
		jsonObject.put("borrower", borrower);
		jsonObject.put("investor", investor);
		jsonObject.put("list", list);
		if(log.isInfoEnabled()){
			log.info("Leave method getOrderAboutInfos success");
		}
		return jsonObject;
	}
	@Override
	public void changeOrderStatus(String orderid) {
		if(log.isInfoEnabled()){
			log.info("Enter method changeOrderStatus success");
		}
		mongoTemplate.upsert(new Query(Criteria.where("orderid").is(orderid)), new Update().set("status", 1), Order.class);
		if(log.isInfoEnabled()){
			log.info("Leave method changeOrderStatus success");
		}
	}
}

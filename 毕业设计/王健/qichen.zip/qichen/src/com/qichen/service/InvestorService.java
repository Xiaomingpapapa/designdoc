package com.qichen.service;

import java.util.List;
import java.util.Map;

import com.alibaba.fastjson.JSONObject;
import com.qichen.po.Investor;

public interface InvestorService {

	/**
	 * 添加投资人
	 * @param investor
	 */
	public void addInvestor(Investor investor);
	
	/**
	 * 根据员工下的投资人映射表 查询投资人
	 * @param map
	 * @return
	 */
	public List<Investor> getInvestorById(Map<String,String> map);
	
	/**
	 * 通过订单号查找投资人信息
	 * @param orderid
	 * @return
	 */
	public Investor findInvestorByOrderId(String orderid);
	
	/**
	 * 投资人添加订单
	 * @param orderid
	 */
	public void  addOrder(String orderid,Long tel);
	
	/**
	 * 查询所有投资人信息
	 * @return
	 */
	public List<Investor> findAllInvestors();
	
	/**
	 * 查询投资人部分信息
	 * @param email
	 * @return
	 */
	public List<JSONObject> findInvestorsInfo(String email);
	
	
}

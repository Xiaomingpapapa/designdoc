package com.qichen.service;

import java.util.List;
import java.util.Map;

import com.alibaba.fastjson.JSONObject;
import com.qichen.po.Borrower;
import com.qichen.po.Order;

public interface BorrowerService {
	
	/**
	 *	添加借款人
	 * @param borrower
	 */
	
	public void addBorrower(Borrower borrower);
	
	
	/**
	 * 更新借款人借款订单列表
	 * @param tel
	 * @param order
	 */
	public void updateBorrowerOrder(Long tel,Order order);

	/**
	 * 验证手机号是否唯一
	 * @param tel
	 * @return
	 */
	public Boolean validateBorrowerByTel(long tel);
	
	/**
	 * 通过Staff的借款人映射表 查询详细借款人信息
	 * @param map
	 * @return
	 */
	public List<Borrower> getBorrowersById(Map<String,String> map);
	
	/**
	 * 通过orderid列表 查询客户
	 * @param list
	 * @return
	 */
	public List<Borrower> findBorrowersByOrderId(List<String> list);
	
	/**
	 * 查询未完成订单中借款人信息
	 * @param id
	 * @return
	 */
	public Borrower findBorrowerByOrderId(String id);
	
	/**
	 * 获取各地区下客户数量   未完成
	 * @param email
	 * @return
	 */
	public List<JSONObject> getCustomerAccount(String email);
	
	/**
	 * 查看所有借款人
	 * @return
	 */
	public List<Borrower> findAllBorrowers();
	
	/**
	 * 查询投资人部分信息
	 * @param email
	 * @return
	 */
	public List<JSONObject> findBorrowersInfo(String email);
}

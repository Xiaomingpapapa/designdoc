package com.qichen.service;

import java.util.List;
import java.util.Map;

import com.alibaba.fastjson.JSONObject;
import com.qichen.po.Borrower;
import com.qichen.po.Dept;
import com.qichen.po.Investor;
import com.qichen.po.Order;
import com.qichen.po.Staff;

public interface StaffService {
	
	/**
	 * 通过用户名与密码与数据库进行验证
	 * @param email
	 * @param password
	 * @return
	 */
	public boolean validateStaff(String email,String password);
	
	/**
	 * 通过唯一索引email 获得员工信息
	 * @param email
	 * @return
	 */
	public Staff  getStaffInfo(String email);
	
	/**
	 * 通过插入Staff对象 注册员工
	 * @param staff
	 */
	public void addStaff(Staff staff);
	
	/**
	 * 更新员工旗下借款人列表
	 * @param borrower
	 * @param email
	 */
	public  void updateStaffBorrrower( Borrower borrower, String email);
	
	/**
	 * 更新员工旗下投资人列表
	 * @param investor
	 * @param email
	 */
	public void updateStaffInvestor( Investor investor,String email);
	
	/**
	 * 修改密码
	 * @param newpwd
	 * @return
	 */
	public boolean changeStaffPwd(String newpwd,String email);
	
	/**
	 * 更新员工订单列表
	 * @param order
	 * @param email
	 */
	public void updateStaffOrder(Order order,String email);
	
	/**
	 * 统计客户总数
	 * @param email
	 * @return
	 */
	public Long countOfCustomer(String email);
		
	/**
	 * 通过订单id 查找是否存在1到两个员工
	 * @param id
	 * @return
	 */
	public boolean findStaffByOrderid(String id);
	
	/**
	 * 通过order号更新员工订单
	 * @param email
	 * @param id
	 */
	public void addOrderToStaff(String email,String id);
	
	/**
	 * 管理员拿取部门列表
	 * @param email
	 * @return
	 */
	public List<Dept> getDeptListByAdmin(String email);
	/**
	 * 通过部门id获取部门内员工姓名
	 * @return
	 */
	public List<String> getStaffNameByDeptId(Long deptid);
	/**
	 * 通过部门id获得部门信息
	 * @param deptid
	 * @return
	 */
	public Dept getDeptByDeptId(Long deptid);
	
	/**
	 * 通过部门id获得整个部门的人员信息
	 * @param deptid
	 * @return
	 */
	public List<Staff> getStaffsInDept(Long deptid);
	
	/**
	 * 更换部门
	 * @param email
	 * @param Deptid
	 * @return
	 */
	public Boolean changeDeptByEmail(String email,Long Deptid);
	
	/**
	 * 移除员工
	 * @param email
	 */
	public void removeStaffByEmail(String email);
	
	/**
	 * 通过部门id删除部门
	 * @param deptid
	 */
	public void removeDeptById(Long deptid);
	
	/**
	 * 创建部门
	 * @param dept
	 * @return
	 */
	public Boolean setupNewDeptById(Dept dept);
	
	/**
	 * 查询订单所属业务员姓名
	 * @param orderid
	 * @return
	 */
	public List<String> findStaffInfoByOrderId(String orderid);
	
	/**
	 * 订单通过审批，状态为4
	 * @param orderid
	 */
	public void changeStatusOrderToOver(String orderid);
	
	/**
	 * 获得当月员工工资
	 * @param email
	 * @return
	 */
	public Long getSalaryOfMonth(String email);
	
	/**
	 * 获取历史订单信息
	 * @param email
	 * @return
	 */
	public List<JSONObject> getTableInfoList(String email);
	
	/**
	 * 获取员工联系列表
	 * @param email
	 * @return
	 */
	public List<JSONObject> getStaffTableInfo();
	
	/**
	 * 验证部门id有效性
	 * @param deptid
	 * @return
	 */
	public boolean validateDept(String deptid);
}

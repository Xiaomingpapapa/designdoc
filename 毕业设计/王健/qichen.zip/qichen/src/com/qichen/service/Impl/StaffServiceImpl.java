package com.qichen.service.Impl;


import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.qichen.po.Borrower;
import com.qichen.po.Dept;
import com.qichen.po.Investor;
import com.qichen.po.Order;
import com.qichen.po.Staff;
import com.qichen.service.StaffService;
import com.sun.org.apache.bcel.internal.generic.NEW;
import com.sun.org.apache.xpath.internal.operations.Bool;
@Service
public class StaffServiceImpl implements StaffService{
	
	@Resource	
	private MongoTemplate mongoTemplate;
	
	private static final Logger log = Logger.getLogger(StaffServiceImpl.class);
	
	public boolean validateStaff(String email, String password) {
		if(log.isInfoEnabled()) {
			log.info("Enter method validateStaff");
		}
		 Staff staff = mongoTemplate.findOne(new Query(Criteria.where("email").is(email)), Staff.class,"Staff");
		 if(staff!=null){
			 if(staff.getPassword().equals(password)){
				 if(log.isInfoEnabled()) {
						log.info("Leave method validateStaff success");
					}
				 return true;
			 }else{
				 if(log.isInfoEnabled()) {
						log.info("Leave method validateStaff success: password error");
					}
				 return false;
			 }
		 }
		 if(log.isInfoEnabled()) {
				log.info("Leave method validateStaff success: no Staff error");
			}
		return false;
	}

	@Override
	public Staff getStaffInfo(String email) {
		if(log.isInfoEnabled()) {
			log.info("Enter method getStaffInfo email: "+email);
		} 
		 Staff staff = mongoTemplate.findOne(new Query(Criteria.where("email").is(email)), Staff.class,"Staff");
		 if(staff!=null){
			 if(log.isInfoEnabled()) {
					log.info("Leave method getStaffInfo success");
				} 
			 return staff;
		 }
		 if(log.isInfoEnabled()) {
				log.info("Leave method getStaffInfo success, No StaffInfo");
			} 
		 return staff;
	}

	@Override
	public void addStaff(Staff staff) {
		if(log.isInfoEnabled()) {
			log.info("Enter method addStaf ");
		}
		mongoTemplate.insert(staff);
		 if(log.isInfoEnabled()) {
				log.info("Leave method addStaf success");
			} 
	}


	@Override
	public void updateStaffBorrrower(Borrower borrower, String email) {
		if(log.isInfoEnabled()) {
			log.info("Enter method updateStaffBorrrower  email: "+email);
		}
		Staff staff = getStaffInfo(email);
		Map<String, String> borrowers = staff.getBorrowers();
		if(borrowers==null){
			borrowers = new HashMap<>();
		}
		borrowers.put(borrower.getBorrowerid(),borrower.getBorrowername());
		mongoTemplate.upsert(new Query(Criteria.where("email").is(email)), new Update().set("borrowers", borrowers),Staff.class, "Staff");
		if(log.isInfoEnabled()) {
			log.info("Leave method updateStaffBorrrower  email: "+email);
		}
	}

	@Override
	public void updateStaffInvestor(Investor investor, String email) {
		if(log.isInfoEnabled()) {
			log.info("Enter method updateStaffInvestor  email: "+email);
		}
		Staff staff = getStaffInfo(email);
		Map<String, String> investors = staff.getInvestors();
		if(investors==null){
			investors = new HashMap<>();
		}
		investors.put(investor.getInvestorId(),investor.getInvestorname());
		mongoTemplate.upsert(new Query(Criteria.where("email").is(email)), new Update().set("investors", investors), Staff.class, "Staff");
		if(log.isInfoEnabled()) {
			log.info("Leave method updateStaffInvestor  email: "+email);
		}
	}

	@Override
	public boolean changeStaffPwd(String newpwd,String email) {
		if(log.isInfoEnabled()) {
			log.info("Enter method changeStaffPwd  success!");
		}
		mongoTemplate.upsert(new Query(Criteria.where("email").is(email)), new Update().set("password", newpwd),Staff.class);
		if(log.isInfoEnabled()) {
			log.info("Leave method changeStaffPwd  success!");
		}
		return true;
	}

	@Override
	public void updateStaffOrder(Order order, String email) {
		if(log.isInfoEnabled()) {
			log.info("Enter method updateStaffOrder  success!");
		}
		Staff staffInfo = getStaffInfo(email);
		List<String> orders = staffInfo.getOrders();
		if(orders == null) orders = new ArrayList<>();
		orders.add(order.getOrderid());
		mongoTemplate.upsert(new Query(Criteria.where("email").is(email)),new Update().set("orders", orders), Staff.class);
		if(log.isInfoEnabled()) {
			log.info("leave method updateStaffOrder  success!");
		}
	}

	@Override
	public Long countOfCustomer(String email) {
		if(log.isInfoEnabled()) {
			log.info("Enter method countOfCustomer  success!");
		}
		Long count =0L;
		Staff staff = mongoTemplate.findOne(new Query(Criteria.where("email").is(email)), Staff.class,"Staff");
		if(staff.getDeptId()==0L){
			  long count2 = mongoTemplate.count(new Query(), Borrower.class);
			  long count3 = mongoTemplate.count(new Query(), Investor.class);
			  count +=count2;
			  count +=count3;
		
		}else {
			
		if(staff.getBorrowers()!=null){
			count+=staff.getBorrowers().size();
		}
		if(staff.getInvestors()!=null){
			count+=staff.getInvestors().size();
		}
		}
		if(log.isInfoEnabled()) {
			log.info("Leave method countOfCustomer  success!");
		}
		return count;
	}

	@Override
	public boolean findStaffByOrderid(String id) {
		if(log.isInfoEnabled()) {
			log.info("Enter method findStaffByOrderid  success!");
		}
		List<Staff> list = mongoTemplate.find(new Query(Criteria.where("orders").in(id)), Staff.class, "Staff");
		if(list.size()<2) {
			if(log.isInfoEnabled()) {
				log.info("Leave method findStaffByOrderid  success!");
			}
			return true;
		}
		if(log.isInfoEnabled()) {
			log.info("Leave method findStaffByOrderid  success!");
		}
		return false;
	}

	@Override
	public void addOrderToStaff(String email, String id) {
		if(log.isInfoEnabled()) {
			log.info("Enter method addOrderToStaff  success!");
		}
		Staff staff = mongoTemplate.findOne(new Query(Criteria.where("email").in(email)), Staff.class, "Staff");
		
		if(staff.getOrders()==null){
			List<String> list = new ArrayList<>();
			list.add(id);
			mongoTemplate.upsert(new Query(Criteria.where("email").is(email)), new Update().set("orders", list), "Staff");
		}else{
			List<String> orders = staff.getOrders();
			orders.add(id);
			mongoTemplate.upsert(new Query(Criteria.where("email").is(email)), new Update().set("orders", orders), "Staff");
		}
		if(log.isInfoEnabled()) {
			log.info("Leave method addOrderToStaff  success!");
		}
	}

	@Override
	public List<Dept> getDeptListByAdmin(String email) {
		if(log.isInfoEnabled()) {
			log.info("Enter method getDeptListByAdmin  success!");
		}
		List<Dept> all = mongoTemplate.findAll(Dept.class,"Dept");
		if(log.isInfoEnabled()) {
			log.info("leave method getDeptListByAdmin  success!");
		}
		return all;
	}

	@Override
	public List<String> getStaffNameByDeptId(Long deptid) {
		if(log.isInfoEnabled()) {
			log.info("Enter method getStaffNameByDeptId  success!");
		}
		List<Staff> list = mongoTemplate.find(new Query(Criteria.where("deptId").is(deptid)), Staff.class, "Staff");
		List<String> names = new ArrayList<>();
		if(list==null){
			if(log.isInfoEnabled()) {
				log.info("Leave method getStaffNameByDeptId  success! null");
			}
			return names;
		}else{
			for (Staff staff : list) {
				String name = staff.getName();
				names.add(name);
			}
			if(log.isInfoEnabled()) {
				log.info("Leave method getStaffNameByDeptId  success!");
			}
			return names;
		}
	}

	@Override
	public Dept getDeptByDeptId(Long deptid) {
		if(log.isInfoEnabled()) {
			log.info("Enter method getDeptByDeptId  success!");
		}
		Dept dept = mongoTemplate.findOne(new Query(Criteria.where("deptid").is(deptid)), Dept.class);
		if(log.isInfoEnabled()) {
			log.info("Leave method getDeptByDeptId  success!");
		}
		return dept;
	}

	@Override
	public List<Staff> getStaffsInDept(Long deptid) {
		if(log.isInfoEnabled()) {
			log.info("Enter method getStaffsInDept  success!");
		}
		List<Staff> list = mongoTemplate.find(new Query(Criteria.where("deptId").is(deptid)), Staff.class, "Staff");
		if(log.isInfoEnabled()) {
			log.info("Leave method getStaffsInDept  success!");
		}
		return list;
	}

	@Override
	public Boolean changeDeptByEmail(String email,Long Deptid) {
		if(log.isInfoEnabled()) {
			log.info("Enter method changeDeptByEmail  success!");
		}
		
		Dept dept = mongoTemplate.findOne(new Query(Criteria.where("deptid").is(Deptid)), Dept.class);
		if(dept==null) return false;
		mongoTemplate.upsert(new Query(Criteria.where("email").is(email)), new Update().set("deptId", Deptid), Staff.class);
		return true;
	}

	@Override
	public void removeStaffByEmail(String email) {
		if(log.isInfoEnabled()) {
			log.info("Enter method removeStaffByEmail  success!");
		}
		mongoTemplate.remove(new Query(Criteria.where("email").is(email)), Staff.class);
		if(log.isInfoEnabled()) {
			log.info("Leave method removeStaffByEmail  success!");
		}
	}

	@Override
	public void removeDeptById(Long deptid) {
		if(log.isInfoEnabled()) {
			log.info("Enter method removeDeptById  success!");
		}
		mongoTemplate.remove(new Query(Criteria.where("deptid").is(deptid)), Dept.class);
		if(log.isInfoEnabled()) {
			log.info("Leave method removeDeptById  success!");
		}
	}

	@Override
	public Boolean setupNewDeptById(Dept dept) {
		if(log.isInfoEnabled()) {
			log.info("Enter method setupNewDeptById  success!");
		}
		Dept findOne = mongoTemplate.findOne(new Query(Criteria.where("deptname").is(dept.getDeptname())), Dept.class);
		Dept findOne2 = mongoTemplate.findOne(new Query(Criteria.where("deptid").is(dept.getDeptid())), Dept.class);
		if(findOne!=null||findOne2!=null){
			return false;
		}else{
			mongoTemplate.insert(dept, "Dept");
			return true;
		}
	}

	@Override
	public List<String> findStaffInfoByOrderId(String orderid) {
		if(log.isInfoEnabled()) {
			log.info("Enter method findStaffInfoByOrderId  success!");
		}
		List<String> names = new ArrayList<>();
		List<Staff> list = mongoTemplate.find(new Query(Criteria.where("orders").in(orderid)), Staff.class, "Staff");
		for (Staff staff : list) {
			names.add(staff.getName());
		}
		if(log.isInfoEnabled()) {
			log.info("Leave method findStaffInfoByOrderId  success!");
		}
		return names;
	}

	@Override
	public void changeStatusOrderToOver(String orderid) {
		if(log.isInfoEnabled()) {
			log.info("Enter method changeStatusOrderToOver  success!");
		}
		mongoTemplate.upsert(new Query(Criteria.where("orderid").is(orderid)), new Update().set("status", 4), "Order");
		if(log.isInfoEnabled()) {
			log.info("Leave method changeStatusOrderToOver  success!");
		}
	}

	@Override
	public Long getSalaryOfMonth(String email) {
		if(log.isInfoEnabled()) {
			log.info("Enter method getSalaryOfMonth  success!");
		}
		 Double salary =0D;
		 Date date = new Date();
		 Date date2 = new Date();
		 Calendar cale = Calendar.getInstance();
	     // 获取前月的第一天  
	     cale = Calendar.getInstance();  
	     cale.add(Calendar.MONTH, 0);  
	     cale.set(Calendar.DAY_OF_MONTH, 1);  
	     cale.set(Calendar.HOUR_OF_DAY, 0);
	     cale.set(Calendar.SECOND,0);
	     cale.set(Calendar.MINUTE,0);
	     date=cale.getTime();
	     // 获取后一月的第一天  
	     cale = Calendar.getInstance();  
	     cale.add(Calendar.MONTH, 1);  
	     cale.set(Calendar.DAY_OF_MONTH, 1);  
	     cale.set(Calendar.HOUR_OF_DAY, 0);
	     cale.set(Calendar.SECOND,0);
	     cale.set(Calendar.MINUTE,0);
	     date2=cale.getTime();
	     Staff staff = mongoTemplate.findOne(new Query(Criteria.where("email").is(email)), Staff.class);
	     List<String> orders = staff.getOrders();
	     if(orders==null){
	    	 return 0L;
	     }else{
	    	 List<Order> list = mongoTemplate.find(new Query(Criteria.where("orderid").in(orders).and("status").gte(4).andOperator(Criteria.where("signingdate").lte(date2).gte(date))), Order.class, "Order");
	    	 if(list==null){
		    	 return 0L;
	    	 }else{
	    		 for (int i = 0; i < list.size(); i++) {
	    			 Double j = 0D;
	    			List<Staff> find = mongoTemplate.find(new Query(Criteria.where("orders").in(list.get(i).getOrderid())), Staff.class);
	    			Order order = list.get(i);
					Long account = order.getAccount();
					Double commission = order.getCommission();
					Double rebate = order.getRebate();
					if(commission>1D&&rebate>1D){
						j=commission-rebate;
					}else if(commission>1D&&rebate<1D){
						j=commission-account*rebate*10000;
					}else if (commission<1D&&rebate>1D) {
						j=10000*account*commission-rebate;
					}else {
						j=10000*account*(commission-rebate);
					}
	    			if(find.size()==2){
	    				j=j/2;
	    			}else{
	    				
	    			}
					salary+=j;
				}
	    	 }
	     }
	     long longValue = salary.longValue();
	     if(log.isInfoEnabled()) {
				log.info("Leave method getSalaryOfMonth  success!");
			}
		return longValue;
	}

	@Override
	public List<JSONObject> getTableInfoList(String email) {
		if(log.isInfoEnabled()) {
			log.info("Enter method getTableInfoList  success!");
		}
		List<JSONObject> infos = new ArrayList<>();
		Staff staff = mongoTemplate.findOne(new Query(Criteria.where("email").is(email)), Staff.class);
		if(staff.getDeptId()==0L){
			List<Order> list = mongoTemplate.find(new Query(Criteria.where("status").gte(4)),Order.class);
			for (Order order : list) {
				JSONObject json = new JSONObject();
				String orderid = order.getOrderid();
				json.put("orderid", orderid);
				json.put("account", order.getAccount());
				json.put("commission", order.getCommission());
				json.put("signingdate", order.getSigningdate());
				json.put("loandate", order.getLoandate());
				json.put("term", order.getTerm());
				json.put("rebate", order.getRebate());
				Borrower borrower = mongoTemplate.findOne(new Query(Criteria.where("orders").is(orderid)), Borrower.class);
				json.put("borrowername",borrower.getBorrowername());
				Investor investor = mongoTemplate.findOne(new Query(Criteria.where("orders").is(orderid)), Investor.class);
				json.put("investorname", investor.getInvestorname());
				infos.add(json);
			}
		}else{
			List<String> orders = staff.getOrders();
			if (orders==null) {
				return infos;
			}else{
				List<Order> find = mongoTemplate.find(new Query(Criteria.where("orderid").in(orders).and("status").gte(4)), Order.class);
				for (Order order : find) {
					JSONObject json = new JSONObject();
					String orderid = order.getOrderid();
					json.put("orderid", orderid);
					json.put("account", order.getAccount());
					json.put("commission", order.getCommission());
					json.put("signingdate", order.getSigningdate());
					json.put("loandate", order.getLoandate());
					json.put("term", order.getTerm());
					json.put("rebate", order.getRebate());
					Borrower borrower = mongoTemplate.findOne(new Query(Criteria.where("orders").is(orderid)), Borrower.class);
					json.put("borrowername",borrower.getBorrowername());
					infos.add(json);
				}
			}
		}
		if(log.isInfoEnabled()) {
			log.info("Leave method getTableInfoList  success!");
		}
		return infos;
	}

	@Override
	public List<JSONObject> getStaffTableInfo() {
		if(log.isInfoEnabled()) {
			log.info("Enter method getStaffTableInfo  success!");
		}
		List<JSONObject> list = new ArrayList<>();
		List<Staff> findAll = mongoTemplate.findAll(Staff.class);
		for (Staff staff : findAll) {
			JSONObject json = new JSONObject();
			json.put("staffname", staff.getName());
			json.put("phone", staff.getTelephone());
			json.put("email", staff.getEmail());
			Dept dept = mongoTemplate.findOne(new Query(Criteria.where("deptid").is(staff.getDeptId())), Dept.class);
			json.put("dept", dept.getDeptname());
			list.add(json);
		}
		if(log.isInfoEnabled()){
			log.info("leave method getStaffTableInfo  success!");
		}
		return list;
	}

	@Override
	public boolean validateDept(String deptid) {
		if(log.isInfoEnabled()) {
			log.info("Enter method validateDept  success!");
		}
		long l = Long.parseLong(deptid);
		Dept findOne = mongoTemplate.findOne(new Query(Criteria.where("deptid").is(l)), Dept.class);
		if (findOne==null) {
			return false;
		}else {
			return true;
		}
	}
	

}

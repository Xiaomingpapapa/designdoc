package com.qichen.service;

import java.text.ParseException;
import java.util.List;

import com.qichen.po.Plan;

public interface PlanService {

	/**
	 * 添加工作计划
	 * @param plan
	 */
	public void addPlan(Plan plan);
	/**
	 * 查询有效的工作计划
	 * @param email
	 * @return
	 * @throws ParseException 
	 */
	public List<Plan> findPlans(String email) throws ParseException;
	
	/**
	 * 移除计划
	 * @param id
	 * @return
	 */
	public boolean removePlanById(String id);
	
	/**
	 * 更新计划
	 * @param plan
	 */
	public void updatePlan(Plan plan);
}

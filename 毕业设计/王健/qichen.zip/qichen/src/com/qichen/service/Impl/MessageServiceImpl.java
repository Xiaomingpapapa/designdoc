package com.qichen.service.Impl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import com.qichen.po.Message;
import com.qichen.service.MessageService;
import com.sun.org.apache.bcel.internal.generic.NEW;
@Service
public class MessageServiceImpl implements MessageService{
	
	private Logger log = Logger.getLogger(MessageServiceImpl.class);
	@Resource
	private MongoTemplate mongoTemplate;
	@Override
	public void addMessage(Message message) {
		if(log.isInfoEnabled()){
			log.info("Enter method addMessage success");
		}
		mongoTemplate.insert(message, "Message");	
		if(log.isInfoEnabled()){
			log.info("Leave method addMessage success");
		}
	}
	@Override
	public List<Message> findMessagesByEmail(String email) {
		if(log.isInfoEnabled()){
			log.info("Enter method findMessagesByEmail success");
		}
		List<Message> list = mongoTemplate.find(new Query(Criteria.where("sendToEmail").is(email)), Message.class);
		if(list==null){
			list = new ArrayList<>();
			if(log.isInfoEnabled()){
				log.info("Leave method findMessagesByEmail success list null");
			}
			return list;
		}
//		for (Message message : list) {
//			if(message.getTitle()==null) {message.setTitle("无标题");}
//			if(message.getStatus()==true) {
//				System.out.println(message.getTitle());
//				list.remove(message);}
//		}
		Iterator<Message> iterator = list.iterator();
		while (iterator.hasNext()) {
			Message message = (Message) iterator.next();
			if(message.getStatus()){
				iterator.remove();
			}
		}
		if(log.isInfoEnabled()){
			log.info("Leave method findMessagesByEmail success");
		}
		return list;
	}
	@Override
	public void changeMessageStatus(String email, long date) {
		if(log.isInfoEnabled()){
			log.info("Enter method changeMessageStatus success");
		}	
		List<Message> list = mongoTemplate.find(new Query(Criteria.where("sendEmail").is(email)), Message.class);
		for (Message message : list) {
			if(message.getDate().equals(new Date(date))){
				mongoTemplate.upsert(new Query(Criteria.where("date").is(new Date(date))), new Update().set("status", true),Message.class);
			}
		}
		if(log.isInfoEnabled()){
			log.info("Leave method changeMessageStatus success");
		}	
	}

}

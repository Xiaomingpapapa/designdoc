package com.qichen.service;

import java.util.List;

import com.qichen.po.Message;

public interface MessageService {
	/**
	 * 添加消息
	 * @param message
	 */
	public void addMessage(Message message);
	
	/**
	 * 通过email查找消息 未读消息 email为被发送的email
	 * @param email
	 * @return
	 */
	public List<Message> findMessagesByEmail(String email);
	
	/**
	 * 通过发送人email和时间更改消息状态
	 * 
	 * @param email
	 * @param date
	 */
	public void changeMessageStatus(String email,long date);
}

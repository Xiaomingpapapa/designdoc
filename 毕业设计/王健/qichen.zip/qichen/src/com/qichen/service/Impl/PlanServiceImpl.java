package com.qichen.service.Impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import com.mongodb.WriteResult;
import com.qichen.po.Plan;
import com.qichen.service.PlanService;
import com.sun.org.apache.bcel.internal.generic.NEW;
@Service
public class PlanServiceImpl implements PlanService{

	private static final Logger log = Logger.getLogger(PlanServiceImpl.class);
	
	@Resource
	private MongoTemplate mongoTemplate;
	
	@Override
	public void addPlan(Plan plan) {
		if(log.isInfoEnabled()){
			log.info("Enter Method addPlan success ");
		}
		mongoTemplate.insert(plan, "Plan");
		if(log.isInfoEnabled()){
			log.info("Enter Method addPlan success ");
		}
	}

	@Override
	public List<Plan> findPlans(String email) throws ParseException {
		if(log.isInfoEnabled()){
			log.info("Enter Method findPlans success ");
		}
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		Date date = new Date();
		//减少一天
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.set(calendar.DATE, calendar.get(calendar.DATE)-1);
		Date d = simpleDateFormat.parse(simpleDateFormat.format(calendar.getTime()));
		List<Plan> list = mongoTemplate.find(new Query(Criteria.where("email").is(email).and("date").gt(d)),Plan.class, "Plan");
		if(log.isInfoEnabled()){
			log.info("Leave Method findPlansan success ");
		}
		return list;
	}

	@Override
	public boolean removePlanById(String id) {
		if(log.isInfoEnabled()){
			log.info("Enter Method removePlanById success ");
		}
		mongoTemplate.remove(new Query(Criteria.where("_id").is(id)), "Plan");
		if(log.isInfoEnabled()){
			log.info("Leave Method removePlanById success ");
		}
		return true;
	}

	@Override
	public void updatePlan(Plan plan) {
		if(log.isInfoEnabled()){
			log.info("Enter Method updatePlan success ");
		}
		removePlanById(plan.getId());
		mongoTemplate.insert(plan, "Plan");
		if(log.isInfoEnabled()){
			log.info("Leave Method updatePlan success ");
		}
	}

}

package com.qichen.service.Impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;import org.springframework.data.mongodb.core.query.CriteriaDefinition;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.qichen.po.Investor;
import com.qichen.po.Staff;
import com.qichen.service.InvestorService;
@Service
public class InvestorServiceImpl implements InvestorService {
	
	private static final Logger log = Logger.getLogger(InvestorServiceImpl.class);
	@Resource
	private MongoTemplate mongoTemplate;
	
	
	public void addInvestor(Investor investor) {
		if(log.isInfoEnabled()) {
			log.info("Enter method addInvestor success");
		}
		mongoTemplate.insert(investor);
		if(log.isInfoEnabled()) {
			log.info("Leave method addInvestor success");
		}
	}


	@Override
	public List<Investor> getInvestorById(Map<String, String> map) {
		if(log.isInfoEnabled()) {
			log.info("Enter method getInvestorById success");
		}
		Set<String> set = map.keySet();
		List<Investor> list = new ArrayList<>();
		for(String string : set){
			Investor investor = mongoTemplate.findOne(new Query(Criteria.where("investorId").is(string)),Investor.class,"Investor");
			list.add(investor);
		}
		if(log.isInfoEnabled()) {
			log.info("Leave method getInvestorById success");
		}
		return list;
	}


	@Override
	public Investor findInvestorByOrderId(String orderid) {
		if(log.isInfoEnabled()) {
			log.info("Enter method findInvestorByOrderId success");
		}
		Investor investor = mongoTemplate.findOne(new Query(Criteria.where("orders").in(orderid)), Investor.class, "Investor");
		if(investor==null){
			investor = new Investor();
		}
		if(log.isInfoEnabled()) {
			log.info("Leave method findInvestorByOrderId success");
		}
		return investor;
	}


	@Override
	public void addOrder(String orderid,Long tel) {
		if(log.isInfoEnabled()) {
			log.info("Enter method addOrder success");
		}
		List<String> list=null;
		Investor findOne = mongoTemplate.findOne(new Query(Criteria.where("orders").in(orderid)), Investor.class);
		if(findOne==null){
		Investor investor = mongoTemplate.findOne(new Query(Criteria.where("investorphone").is(tel)), Investor.class);
		if(investor.getOrders()==null){
		list = new ArrayList<>();
		list.add(orderid);
		}else{
			list =investor.getOrders();
			if(!isInList(list, orderid)) list.add(orderid);
			
		}
		mongoTemplate.upsert(new Query(Criteria.where("investorphone").is(tel)), new Update().set("orders", list), "Investor");
		}else{
			Investor investor = mongoTemplate.findOne(new Query(Criteria.where("investorphone").is(tel)), Investor.class);
			if(investor.getInvestorId().equals(findOne.getInvestorId())){
				
			}else{
				if(investor.getOrders()==null){
					list = new ArrayList<>();
					list.add(orderid);
					}else{
						list =investor.getOrders();
						if(!isInList(list, orderid)) list.add(orderid);
						
					}
					mongoTemplate.upsert(new Query(Criteria.where("investorphone").is(tel)), new Update().set("orders", list), "Investor");
					List<String> old = findOne.getOrders();
					old.remove(orderid);
					mongoTemplate.upsert(new Query(Criteria.where("orders").in(orderid)), new Update().set("orders", old), "Investor");
				
			}
		}
		if(log.isInfoEnabled()) {
			log.info("Leave method addOrder success");
		}
	}
	/**
	 * 判断是否在list 中
	 * @param list
	 * @param ex
	 * @return
	 */
	public Boolean isInList(List<String>list,String ex){
		Boolean result =false;
		for (String string : list) {
			if(ex.equals(string)){
				result=true;
			}
		}
		return result;
		
	}


	@Override
	public List<Investor> findAllInvestors() {
		if(log.isInfoEnabled()) {
			log.info("Enter method findAllInvestors success");
		}
		List<Investor> findAll = mongoTemplate.findAll(Investor.class);
		if(log.isInfoEnabled()) {
			log.info("Leave method findAllInvestors success");
		}
		return findAll;
	}


	@Override
	public List<JSONObject> findInvestorsInfo(String email) {
		if(log.isInfoEnabled()) {
			log.info("Enter method findInvestorsInfo success");
		}
		List<JSONObject> list = new ArrayList<>();
		Staff staff = mongoTemplate.findOne(new Query(Criteria.where("email").is(email)), Staff.class);
		if(staff.getDeptId()==0L){
			List<Investor> all = mongoTemplate.findAll(Investor.class);
			for (Investor investor : all) {
				JSONObject json = new JSONObject();
				json.put("investorname", investor.getInvestorname());
				json.put("investorphone", investor.getInvestorphone());
				json.put("account", investor.getAccountofmoney()); 
				list.add(json);
			}
		}else{
			Map<String, String> investors = staff.getInvestors();
			if (investors==null) {
				return list;
			}else {
				Set<String> keySet = investors.keySet();
				List<Investor> find = mongoTemplate.find(new Query(Criteria.where("investorId").in(keySet)), Investor.class, "Investor");
				for (Investor investor : find) {
					JSONObject json = new JSONObject();
					json.put("investorname", investor.getInvestorname());
					json.put("investorphone", investor.getInvestorphone());
					json.put("account", investor.getAccountofmoney()); 
					list.add(json);
				}
			}
		}
		if(log.isInfoEnabled()) {
			log.info("Leave method findInvestorsInfo success");
		}
		return list;
	}
}

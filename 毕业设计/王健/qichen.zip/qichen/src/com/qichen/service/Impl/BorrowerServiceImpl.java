package com.qichen.service.Impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.mongodb.WriteResult;
import com.qichen.po.Borrower;
import com.qichen.po.Investor;
import com.qichen.po.Order;
import com.qichen.po.Staff;
import com.qichen.service.BorrowerService;
@Service
public class BorrowerServiceImpl implements BorrowerService {

	private static final Logger log = Logger.getLogger(BorrowerServiceImpl.class);
	@Resource
	private MongoTemplate mongoTemplate;
	
	@Override
	public void addBorrower(Borrower borrower) {
		if(log.isInfoEnabled()) {
			log.info("Enter method addBorrower");
		}
		mongoTemplate.insert(borrower, "Borrower");
		if(log.isInfoEnabled()) {
			log.info("Leave method addBorrower success");
		}
	}


	@Override
	public void updateBorrowerOrder(Long tel, Order order) {
			if(log.isInfoEnabled()) {
				log.info("Enter method updateBorrowerOrder success");
			}
			 Borrower borrower = mongoTemplate.findOne(new Query(Criteria.where("borrowerphone").is(tel)), Borrower.class,"Borrower");
			 List<String> orders = borrower.getOrders();
			 if(orders==null){
				 orders = new ArrayList<>();
			 }
			 orders.add(order.getOrderid());
			 mongoTemplate.upsert(new Query(Criteria.where("borrowerphone").is(tel)),new Update().set("orders", orders), Borrower.class);
			 if(log.isInfoEnabled()) {
					log.info("Leave method updateBorrowerOrder success");
				}
			
	}

	@Override
	public Boolean validateBorrowerByTel(long tel) {
		if(log.isInfoEnabled()) {
			log.info("Enter method validateBorrowerByTel success");
		}
		Borrower borrower = mongoTemplate.findOne(new Query(Criteria.where("borrowerphone").is(tel)),Borrower.class, "Borrower");
		if(borrower!=null){
			if(log.isInfoEnabled()) {
				log.info("Leave method validateBorrowerByTel success");
			}
			return true;
		}
		if(log.isInfoEnabled()) {
			log.info("Leave method validateBorrowerByTel No Borrower");
		}
		return false;
	}


	@Override
	public List<Borrower> getBorrowersById(Map<String, String> map) {
		if(log.isInfoEnabled()) {
			log.info("Enter method getBorrowersById success");
		}
		Set<String> set = map.keySet();
		List<Borrower> list = new ArrayList<>();
		for (String str : set) {
			Borrower borrower = mongoTemplate.findOne(new Query(Criteria.where("borrowerid").is(str)),Borrower.class, "Borrower");
			list.add(borrower);
		}
		return list;
	}


	@Override
	public List<Borrower> findBorrowersByOrderId(List<String> list) {
		if(log.isInfoEnabled()) {
			log.info("Enter method findBorrowersByOrderId success");
		}
		List<Borrower> borrowers= new ArrayList<>();
		if(list.size()==0){
			return borrowers;
		}
		borrowers = mongoTemplate.find(new Query(Criteria.where("orders").in(list)), Borrower.class);
		if(borrowers==null){
			borrowers= new ArrayList<>();
		}
		if(log.isInfoEnabled()) {
			log.info("Leave method findBorrowersByOrderId success");
		}
		return borrowers;
	}


	@Override
	public Borrower findBorrowerByOrderId(String id) {
		if(log.isInfoEnabled()) {
			log.info("Enter method findBorrowerByOrderId success");
		}
		Borrower borrower = mongoTemplate.findOne(new Query(Criteria.where("orders").in(id)), Borrower.class, "Borrower");
		if(log.isInfoEnabled()) {
			log.info("Leave method findBorrowerByOrderId success");
		}
		return borrower;
	}


	@Override
	public List<JSONObject> getCustomerAccount(String email) {
		if(log.isInfoEnabled()) {
			log.info("Enter method getCustomerAccount success");
		}
		Staff staff = mongoTemplate.findOne(new Query(Criteria.where("email").is(email)), Staff.class);
		if(staff.getDeptId()==0L){
			List<Borrower> list = mongoTemplate.findAll(Borrower.class, "Borrower");
			List<Investor> list2 = mongoTemplate.findAll(Investor.class, "Investor");
			List<JSONObject> result= new ArrayList<>();
			
			for (Investor investor : list2) {
				JSONObject jsonObject=new JSONObject();
				if(investor.getAddress().indexOf("黄浦区")!=-1){
					jsonObject.put("name","黄浦区" );
					jsonObject.put("value",3);
				}else if (investor.getAddress().indexOf("徐汇区")!=-1) {
					
				}else if (investor.getAddress().indexOf("长宁区")!=-1) {
					
				}else if (investor.getAddress().indexOf("静安区")!=-1) {
					
				}else if (investor.getAddress().indexOf("普陀区")!=-1) {
					
				}else if (investor.getAddress().indexOf("闸北区")!=-1) {
					
				}else if (investor.getAddress().indexOf("虹口区")!=-1) {
					
				}else if (investor.getAddress().indexOf("杨浦区")!=-1) {
					
				}else if (investor.getAddress().indexOf("闵行区")!=-1) {
					
				}else if (investor.getAddress().indexOf("宝山区")!=-1) {
					
				}else if (investor.getAddress().indexOf("嘉定区")!=-1) {
					
				}else if (investor.getAddress().indexOf("浦东新区")!=-1) {
					
				}else if (investor.getAddress().indexOf("松江区")!=-1) {
					
				}else if (investor.getAddress().indexOf("青浦区")!=-1) {
					
				}else if (investor.getAddress().indexOf("奉贤区")!=-1) {
					
				}else if (investor.getAddress().indexOf("崇明县")!=-1) {
					
				}else if (investor.getAddress().indexOf("金山区")!=-1) {
					
				}else {
					
				}
			}
		}else{
			if(staff.getBorrowers()==null){
						
			}
		}
		return null;
	}


	@Override
	public List<Borrower> findAllBorrowers() {
		if(log.isInfoEnabled()) {
			log.info("Enter method findAllBorrowers success");
		}
		List<Borrower> findAll = mongoTemplate.findAll(Borrower.class);
		if(log.isInfoEnabled()) {
			log.info("Leave method findAllBorrowers success");
		}
		return findAll;
	}


	@Override
	public List<JSONObject> findBorrowersInfo(String email) {
		if(log.isInfoEnabled()) {
			log.info("Enter method findBorrowersInfo success");
		}
		List<JSONObject> list = new ArrayList<>();
		Staff staff = mongoTemplate.findOne(new Query(Criteria.where("email").is(email)), Staff.class);
		if(staff.getDeptId()==0L){
			List<Borrower> findAll = mongoTemplate.findAll(Borrower.class);
			for (Borrower borrower : findAll) {
				JSONObject json = new JSONObject();
				List<String> orders = borrower.getOrders();
				if(orders==null){
					json.put("account", 0);
					json.put("borrowername", borrower.getBorrowername());
					json.put("borrowerphone", borrower.getBorrowerphone());
				}else{
				List<Order> find = mongoTemplate.find(new Query(Criteria.where("orderid").in(orders)), Order.class);
				if (find==null) {
					json.put("account", 0);
				}else {
					long i =0L;
					for (Order order : find) {
						i +=order.getAccount();
					}
					json.put("account", i);
				}
				json.put("borrowername", borrower.getBorrowername());
				json.put("borrowerphone", borrower.getBorrowerphone());
				list.add(json);
			}
			}
		}else {
			Map<String, String> borrowers = staff.getBorrowers();
			if (borrowers==null) {
				return list;
			}else {
				Set<String> keySet = borrowers.keySet();
				List<Borrower> find = mongoTemplate.find(new Query(Criteria.where("borrowerid").in(keySet)), Borrower.class);
				for (Borrower borrower : find) {
					JSONObject json = new JSONObject();
					List<String> orders = borrower.getOrders();
					if(orders==null){
						json.put("account", 0);
						json.put("borrowername", borrower.getBorrowername());
						json.put("borrowerphone", borrower.getBorrowerphone());
					}else{
					List<Order> find2 = mongoTemplate.find(new Query(Criteria.where("orderid").in(orders)), Order.class);
					if (find2==null) {
						json.put("account", 0);
					}else {
						long i =0L;
						for (Order order : find2) {
							i +=order.getAccount();
						}
						json.put("account", i);
					}
					json.put("borrowername", borrower.getBorrowername());
					json.put("borrowerphone", borrower.getBorrowerphone());
					list.add(json);
				}
				}
			}
		}
		if(log.isInfoEnabled()) {
			log.info("Enter method findBorrowersInfo success");
		}
		return list;
	}
	

}

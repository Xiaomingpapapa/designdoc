package com.qichen.service;

import java.util.List;
import java.util.Map;

import com.alibaba.fastjson.JSONObject;
import com.qichen.po.Order;
import com.qichen.po.OrderSub;

public interface OrderService {

	/**
	 * 增加订单到Order collection
	 *
	 * @param order
	 */
	public void addOrder(Order order);
	
	/**
	 * 将订单推入轮播库
	 * @param sub
	 */
	public void pushOrderSub(OrderSub sub);
	
	/**
	 * 通过id查询订单
	 * @param id
	 * @return
	 */
	public Order findOrderById(String id);
	/**
	 * 查出所有需要滚动的信息
	 * @return
	 */
	public List<OrderSub> findAll();
	
	/**
	 * 查出个人所有非完成状态的订单 status!=4 
	 * @return
	 */
	public List<Order> findALLOrderToDeal(List<String> orders);
	
	public void changeOrder(Order order);
	
	/**
	 * 提交订单 等待审批，status更改为3
	 * @param id
	 * @param signingdate
	 * @param loandate
	 */
	public void commitOrder(String id,String signingdate,String loandate);
	
	/**
	 * 移除订单 status=1或2
	 * @param id
	 * @return
	 */
	public Boolean removeOrder(String id);
	
	/**
	 * 通过email查看已完成的订单列表
	 * @param email
	 * @return
	 */
	public List<Order> getDealOrders(String email);
	
	/**
	 * 获取待审批订单
	 * @param email
	 * @return
	 */
	public List<Order> getWaitToDealOrders(String email);
	
	/**
	 * 完成编辑后删除 发布的消息
	 * @param orderid
	 */
	public void removeOrderSub(String orderid);
	
	/**
	 * 获取部分催息列表
	 * @param email
	 * @return
	 */
	public List<Order> getOrderToPayInterest(String email);
	/**
	 * 获取全部催息列表
	 * @return
	 */
	public List<Order> getAllOrderToPayInterest();
	
	/**
	 * 获取业绩 按月进行
	 * @param email
	 * @param lastyear -表示年份向前，
	 * @return
	 */
	public List<Long> getPerformanceOfMonth(String email,int lastyear);
	
	/**
	 * 获取与上个月业绩比
	 * @param email
	 * @return
	 */
	public Double getPercentOfAccount(String email);
	
	/**
	 * 获取与上个月订单数量比
	 * @param email
	 * @return
	 */
	public Double getPercentOfNum(String email);
	
	/**
	 * 获取订单数量 按月
	 * @param email
	 * @param lastyear  -表示年份向前，
	 * @return
	 */
	public List<Long> getOrderCountOfMonth(String email,int lastyear);
	
	/**
	 * 获取订单列表下贷款人信息
	 * @param list
	 * @return
	 */
	public JSONObject getOrdersBorrowersInfo(List<String> list);
	
	/**
	 * 获取订单列表下投资人信息
	 * @param list
	 * @return
	 */
	public JSONObject getOrdersInvestorsInfo(List<String> list);
	/**
	 * 获取订单相关详情
	 * @return
	 */
	public  JSONObject getOrderAboutInfos(String orderid);
	
	/**
	 * 更改订单状态回1
	 * @param orderid
	 */
	public void changeOrderStatus(String orderid);
}

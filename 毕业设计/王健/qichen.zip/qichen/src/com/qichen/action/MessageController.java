package com.qichen.action;

import java.util.Date;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONObject;
import com.qichen.service.BorrowerService;
import com.qichen.service.InvestorService;
import com.qichen.service.MessageService;
import com.qichen.service.StaffService;
@Controller
public class MessageController {

private static final Logger log = Logger.getLogger(MessageController.class);
	
	@Resource
	private StaffService staffServiceImpl;
	@Resource
	private BorrowerService borrowerServiceImpl;
	@Resource
	private InvestorService investorServiceImpl;
	@Resource
	private MessageService messageServiceImpl;
	
	//改变message状态
	@RequestMapping("changeMessageStatus.do")
	@ResponseBody
	public JSONObject changeMessageStatus(String email,Long date){
		if(log.isInfoEnabled()){
			log.info("Enter Method changeMessageStatus email"+email);
		}
		JSONObject jsonObject = new JSONObject();
		messageServiceImpl.changeMessageStatus(email, date);
		jsonObject.put("result", true);
		if(log.isInfoEnabled()){
			log.info("Leave Method changeMessageStatus email"+email);
		}
		return jsonObject;
		
	}
}

package com.qichen.action;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.qichen.po.Order;
import com.qichen.po.Staff;
import com.qichen.service.OrderService;
import com.qichen.service.StaffService;

@Controller
public class ConsoleController {
	
	private static final Logger log = Logger.getLogger(ConsoleController.class);
	@Resource
	private StaffService staffServiceImpl;
	
	@Resource
	private OrderService orderServiceImpl;
	
	@RequestMapping(" widgetsInit.do")
	public String  widgetsInit(String email,Model model){
		if(log.isInfoEnabled()) {
			log.info("Enter method widgetsInit");
		}
		Staff staff = staffServiceImpl.getStaffInfo(email);
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("staff", staff);
		String name = staff.getName();
		model.addAttribute("username", name);
		model.addAttribute("data", jsonObject);
		if(log.isInfoEnabled()) {
			log.info("Leave method widgetsInit");
		}
		return "widgets";
		
	}
	
	@RequestMapping("chartsInit.do")
	public String chartsInit(String email,Model model){
		if(log.isInfoEnabled()) {
			log.info("Enter method chartsInit");
		}
		Staff staff = staffServiceImpl.getStaffInfo(email);
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("staff", staff);
		String name = staff.getName();
		model.addAttribute("username", name);
		model.addAttribute("data", jsonObject);
		if(log.isInfoEnabled()) {
			log.info("Leave method chartsInit");
		}
		return "charts";
	}
	
	@RequestMapping("tablesInit.do")
	public String tablesInit(String email,Model model){
		if(log.isInfoEnabled()) {
			log.info("Enter method tablesInit");
		}
		Staff staff = staffServiceImpl.getStaffInfo(email);
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("staff", staff);
		String name = staff.getName();
		model.addAttribute("username", name);
		model.addAttribute("data", jsonObject);
		if(log.isInfoEnabled()) {
			log.info("Leave method tablesInit");
		}
		return "tables";
	}
	
	@RequestMapping("formsInit.do")
	public String formsInit(String email,Model model){
		if(log.isInfoEnabled()) {
			log.info("Enter method formsInit");
		}
		Staff staff = staffServiceImpl.getStaffInfo(email);
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("staff", staff);
		String name = staff.getName();
		model.addAttribute("username", name);
		model.addAttribute("data", jsonObject);
		if(log.isInfoEnabled()) {
			log.info("Leave method formsInit");
		}
		return "forms";
	}
	
	@RequestMapping("panelsInit.do")
	public String panelsInit(String email,Model model){
		if(log.isInfoEnabled()) {
			log.info("Enter method panelsInit");
		}
		Staff staff = staffServiceImpl.getStaffInfo(email);
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("staff", staff);
		String name = staff.getName();
		model.addAttribute("username", name);
		model.addAttribute("data", jsonObject);
		if(log.isInfoEnabled()) {
			log.info("Leave method panelsInit");
		}
		return "panels";
	}
	@RequestMapping("homeInit.do")
	public String  homeInit(String email,Model model){
		if(log.isInfoEnabled()) {
			log.info("Enter method homeInit");
		}
		Staff staff = staffServiceImpl.getStaffInfo(email);
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("staff", staff);
		String name = staff.getName();
		model.addAttribute("username", name);
		model.addAttribute("data", jsonObject);
		if(log.isInfoEnabled()) {
			log.info("Leave method homeInit");
		}
		return "home";
	}
	//轮播a 标签
	@RequestMapping("doFinishOrder.do")
	public String finishOrder(String email,String orderid,Model model){
		if(log.isInfoEnabled()) {
			log.info("Enter method finishOrder");
		}
		Staff staff = staffServiceImpl.getStaffInfo(email);
		Order order = orderServiceImpl.findOrderById(orderid);
		Object json = JSON.toJSON(staff);
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("staff", staff);
		jsonObject.put("order", order);
		model.addAttribute("data", jsonObject);
		model.addAttribute("staff",json);
		if(log.isInfoEnabled()) {
			log.info("Leave method finishOrder");
		}
		return "widgets" ;
		
	}
}

package com.qichen.action;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.json.Json;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.alibaba.fastjson.JSONObject;
import com.qichen.po.Borrower;
import com.qichen.po.Dept;
import com.qichen.po.Investor;
import com.qichen.po.Message;
import com.qichen.po.Order;
import com.qichen.po.OrderSub;
import com.qichen.po.Plan;
import com.qichen.po.Staff;
import com.qichen.service.BorrowerService;
import com.qichen.service.InvestorService;
import com.qichen.service.MessageService;
import com.qichen.service.OrderService;
import com.qichen.service.PlanService;
import com.qichen.service.StaffService;
import com.qichen.service.Impl.PlanServiceImpl;
import com.qichen.util.DateUtil;
import com.sun.org.apache.regexp.internal.recompile;

@Controller
public class InfoController {

	private static final Logger log = Logger.getLogger(InfoController.class);
	
	@Resource
	private StaffService staffServiceImpl;
	@Resource
	private BorrowerService borrowerServiceImpl;
	@Resource
	private InvestorService investorServiceImpl;
	@Resource
	private OrderService orderServiceImpl;
	@Resource
	private MessageService messageServiceImpl;
	@Resource
	private PlanService planServiceImpl;
	
	//客户管理界面获得借款人信息
	@RequestMapping("doBorrowerInfoList.do")
	@ResponseBody
	public JSONObject BorrowerInfoList(String email){
		if(log.isInfoEnabled()){
			log.info("Enter Method BorrowerInfoList email"+email);
		}
		JSONObject jsonObject = new JSONObject();
		Staff staff = staffServiceImpl.getStaffInfo(email);
		if (staff.getDeptId()==0L) {
			List<Borrower> borrowers = borrowerServiceImpl.findAllBorrowers();
			jsonObject.put("result", true);
			jsonObject.put("borrowers", borrowers);
		}else{
		if(staff==null||staff.getBorrowers()==null){
			jsonObject.put("result", false);
			return jsonObject;
		}
		Map<String, String> borrowers = staff.getBorrowers();
		if(borrowers==null){
			jsonObject.put("result", false);
			return jsonObject;
		}
		List<Borrower> borrowersById = borrowerServiceImpl.getBorrowersById(borrowers);
		jsonObject.put("result", true);
		jsonObject.put("borrowers", borrowersById);
		}
		if(log.isInfoEnabled()){
			log.info("Leave Method BorrowerInfoList ");
		}
		return jsonObject;
	}
	//客户管理界面获得投资人信息
	@RequestMapping("doInvestorInfoList.do")
	@ResponseBody
	public JSONObject InvestorInfoList(String email){
		if(log.isInfoEnabled()){
			log.info("Enter Method InvestorInfoList email"+email);
		}
		JSONObject jsonObject = new JSONObject();
		Staff staff = staffServiceImpl.getStaffInfo(email);
		if(staff.getDeptId()==0L){
			List<Investor> findAllInvestors = investorServiceImpl.findAllInvestors();
			jsonObject.put("result", true);
			jsonObject.put("investors", findAllInvestors);
		}else{
		if(staff==null||staff.getBorrowers()==null){
			jsonObject.put("result", false);
			return jsonObject;
		}
		Map<String, String> investors = staff.getInvestors();
		if(investors==null){
			jsonObject.put("result", false);
			return jsonObject;
		}
		List<Investor> investorById = investorServiceImpl.getInvestorById(investors);
		jsonObject.put("result", true);
		jsonObject.put("investors", investorById);
		}
		if(log.isInfoEnabled()){
			log.info("Leave Method InvestorInfoList success");
		}
		return jsonObject;
	}
	//获得滚动数据
	@RequestMapping("getPublishList.do")
	@ResponseBody
	public JSONObject getPublishList(){
		if(log.isInfoEnabled()){
			log.info("Enter Method getPublishList success");
		}
		JSONObject jsonObject = new JSONObject();
		List<OrderSub> all = orderServiceImpl.findAll();
		jsonObject.put("result", true);
		jsonObject.put("all", all);
		if(log.isInfoEnabled()){
			log.info("Leave Method getPublishList success");
		}
		return jsonObject;
	}
	
	//返回未完成订单列表与未读消息列表
	@RequestMapping("noReadMessage.do")
	@ResponseBody
	public JSONObject noDealMessage(String email){
		if(log.isInfoEnabled()){
			log.info("Enter Method noDealMessage success");
		}
		JSONObject jsonObject = new JSONObject();
		List<Message> list = messageServiceImpl.findMessagesByEmail(email);
		jsonObject.put("message", list);
		Staff staff = staffServiceImpl.getStaffInfo(email);
		List<String> orders = staff.getOrders();
		if(orders==null) orders = new ArrayList<>();
		List<Order> l = orderServiceImpl.findALLOrderToDeal(orders);
		List<String> li = new ArrayList<>();
		if(l.size()==0){
			
		}else{
		for (Order order : l) {
			li.add(order.getOrderid());
		}
		}
		List<Borrower> byOrderId = borrowerServiceImpl.findBorrowersByOrderId(li);
		jsonObject.put("order", l);
		jsonObject.put("result", true);
		jsonObject.put("borrowers", byOrderId);
		if(log.isInfoEnabled()){
			log.info("Leave Method noDealMessage success");
		}
		return jsonObject;
		
	}
	@RequestMapping("doPlanList.do")
	@ResponseBody
	public JSONObject planList(String email){
		if(log.isInfoEnabled()){
			log.info("Enter Method planList success");
		}
		JSONObject jsonObject = new JSONObject();
		List<Plan> list= null;
		try {
			list = planServiceImpl.findPlans(email);
			if(list==null){
				list = new ArrayList<>();
				jsonObject.put("plans", list);
				jsonObject.put("result", false);
				return jsonObject;
			}
			
		} catch (ParseException e) {
			e.printStackTrace();
		}
		jsonObject.put("plans", list);
		jsonObject.put("result", true);
		return jsonObject;
		
	}
	/**
	 * 获取单个未完成订单的借款人与投资人,业务员信息
	 * @param orderid
	 * @return
	 */
	@RequestMapping("OneOrderBorrower.do")
	@ResponseBody
	public JSONObject oneOrderOneBorrower(String orderid){
		if(log.isInfoEnabled()){
			log.info("Enter Method oneOrderOneBorrower success");
		}
		JSONObject jsonObject = new JSONObject();
		Borrower borrower = borrowerServiceImpl.findBorrowerByOrderId(orderid);
		Investor investor = investorServiceImpl.findInvestorByOrderId(orderid);
		List<String> list = staffServiceImpl.findStaffInfoByOrderId(orderid);
		jsonObject.put("result", true);
		jsonObject.put("investor", investor);
		jsonObject.put("borrower", borrower);
		jsonObject.put("staffs",list );
		if(log.isInfoEnabled()){
			log.info("Leave Method oneOrderOneBorrower success");
		}
		return jsonObject;
	}
	@RequestMapping("doOrderToDealInfo.do")
	@ResponseBody
	public JSONObject OrderToDealInfo(String orderid){
		if(log.isInfoEnabled()){
			log.info("Enter Method OrderToDealInfo success");
		}
		JSONObject jsonObject = new JSONObject();
		Borrower borrower = borrowerServiceImpl.findBorrowerByOrderId(orderid);
		Investor investor = investorServiceImpl.findInvestorByOrderId(orderid);
		Order order = orderServiceImpl.findOrderById(orderid);
		List<String> list = staffServiceImpl.findStaffInfoByOrderId(orderid);
		jsonObject.put("result", true);
		jsonObject.put("investor", investor);
		jsonObject.put("borrower", borrower);
		jsonObject.put("staffs",list );
		jsonObject.put("order", order);
		if(log.isInfoEnabled()){
			log.info("Leave Method OrderToDealInfo success");
		}
		return jsonObject;
	}
	/**
	 * 获得客户数量
	 * @param email
	 * @return
	 */
	@RequestMapping("doGetCustomerNum.do")
	@ResponseBody
	public JSONObject customerCount(String email){
		if(log.isInfoEnabled()){
			log.info("Enter Method customerCount success");
		}
		Long countOfCustomer = staffServiceImpl.countOfCustomer(email);
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("result", true);
		jsonObject.put("count", countOfCustomer);
		if(log.isInfoEnabled()){
			log.info("Leave Method customerCount success");
		}
		return jsonObject;
	}
	/**
	 * 验证一个订单最多两个员工所属
	 * @param id
	 * @return
	 */
	@RequestMapping("OneOrderTwoStaff.do")
	@ResponseBody
	public JSONObject findPartner(String id){
		if(log.isInfoEnabled()){
			log.info("Enter Method findPartner success");
		}
		boolean b = staffServiceImpl.findStaffByOrderid(id);
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("result", b);
		if(log.isInfoEnabled()){
			log.info("Leave Method findPartner success");
		}
		return jsonObject;
	}
	/**
	 * 管理员获得部门列表
	 * @param email
	 * @return
	 */
	@RequestMapping("dodeptlist.do")
	@ResponseBody
	public JSONObject getDeptList(String email){
		if(log.isInfoEnabled()){
			log.info("Enter Method getDeptList success");
		}
		JSONObject jsonObject = new JSONObject();
		Staff staff = staffServiceImpl.getStaffInfo(email);
		if(staff.getDeptId()!=0L){
			jsonObject.put("result", false);
		}else {
			List<Dept> list = staffServiceImpl.getDeptListByAdmin(email);
			jsonObject.put("result", true);
			jsonObject.put("dept", list);
		}
		return jsonObject;
	}
	/**
	 * 获取部门详情
	 * @param deptid
	 * @return
	 */
	@RequestMapping("dodeptInfo.do")
	@ResponseBody
	public JSONObject getDeptInfo(Long deptid){
		if(log.isInfoEnabled()){
			log.info("Enter Method getDeptInfo success");
		}
		Dept dept = staffServiceImpl.getDeptByDeptId(deptid);
		List<String> list = staffServiceImpl.getStaffNameByDeptId(deptid);
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("result", true);
		jsonObject.put("dept", dept);
		jsonObject.put("staffs", list);
		if(log.isInfoEnabled()){
			log.info("Leave Method getDeptInfo success");
		}
		return jsonObject;
		
	}
	@RequestMapping("getStaffsInDept.do")
	@ResponseBody
	public JSONObject getStaffsInDept(Long deptid){
		if(log.isInfoEnabled()){
			log.info("Enter Method getStaffsInDept success");
		}
		List<Staff> dept = staffServiceImpl.getStaffsInDept(deptid);
		JSONObject jsonObject= new JSONObject();
		if(dept==null){
			jsonObject.put("result", false);
		}else{
			jsonObject.put("result", true);
			jsonObject.put("staffs", dept);
		}
		return jsonObject;
		}
	/**
	 * home.jsp获取已经完成订单列表
	 * @param email
	 * @return
	 */
	@RequestMapping("doDealOrderList.do")
	@ResponseBody
	public JSONObject doDealOrders(String email){
		if(log.isInfoEnabled()){
			log.info("Enter Method getStaffsInDept success");
		}
		List<Order> orders = orderServiceImpl.getDealOrders(email);
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("result", true);
		jsonObject.put("orders", orders);
		if(log.isInfoEnabled()){
			log.info("Leave Method getStaffsInDept success");
		}
		return jsonObject;
	}
	/**
	 * 获得待审批订单列表
	 * @param email
	 * @return
	 */
	@RequestMapping("doWaitToDealOrders.do")
	@ResponseBody
	public JSONObject WaitToDealOrders(String email){
		if(log.isInfoEnabled()){
			log.info("Enter Method WaitToDealOrders success");
		}
		List<Order> orders = orderServiceImpl.getWaitToDealOrders(email);
		JSONObject jObject =new JSONObject();
		jObject.put("result", true);
		jObject.put("orders", orders);
		if(log.isInfoEnabled()){
			log.info("Leave Method WaitToDealOrders success");
		}
		return jObject;
	}
	/**
	 * 通过email 获取个人催息信息
	 * @param email
	 * @return
	 */
	@RequestMapping("doToPayInterestList.do")
	@ResponseBody
	public JSONObject doToPayInterestList (String email){
		if(log.isInfoEnabled()){
			log.info("Enter Method doToPayInterestList success");
		}
		List<Order> list = orderServiceImpl.getOrderToPayInterest(email);
		List<String> orders = new ArrayList<>();
		JSONObject info = new JSONObject();
		JSONObject info2 = new JSONObject();
		if(list!=null){
		for (Order order : list) {
			orders.add(order.getOrderid());
		}
		info = orderServiceImpl.getOrdersBorrowersInfo(orders);
	    info2= orderServiceImpl.getOrdersInvestorsInfo(orders);
		}
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("result", true);
		jsonObject.put("borrowersinfo", info);
		jsonObject.put("investorsinfo", info2);
		jsonObject.put("orders", list);
		if(log.isInfoEnabled()){
			log.info("Leave Method doToPayInterestList success");
		}
		return jsonObject;
	}
	/**
	 * 获取全部待催息订单
	 * @return
	 */
	@RequestMapping("doAllToPayInterestList.do")
	@ResponseBody
	public JSONObject doAllToPayInterestList(){
		if(log.isInfoEnabled()){
			log.info("Enter Method doAllToPayInterestList success");
		}
		List<Order> list = orderServiceImpl.getAllOrderToPayInterest();
		List<String> orders = new ArrayList<>();
		JSONObject info = new JSONObject();
		JSONObject info2 = new JSONObject();
		if(list!=null){
		for (Order order : list) {
			orders.add(order.getOrderid());
		}
		info = orderServiceImpl.getOrdersBorrowersInfo(orders);
	    info2= orderServiceImpl.getOrdersInvestorsInfo(orders);
		}
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("result", true);
		jsonObject.put("borrowersinfo", info);
		jsonObject.put("investorsinfo", info2);
		jsonObject.put("orders", list);
		if(log.isInfoEnabled()){
			log.info("Leave Method doAllToPayInterestList success");
		}
		return jsonObject;
	}
	/**
	 * 获取员工业绩（非正确工资）
	 * @param email
	 * @return
	 */
	@RequestMapping("doGetSalary.do")
	@ResponseBody
	public JSONObject doGetSalary(String email){
		if(log.isInfoEnabled()){
			log.info("Enter Method doGetSalary success");
		}
		Long salaryOfMonth = staffServiceImpl.getSalaryOfMonth(email);
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("result", true);
		jsonObject.put("salary", salaryOfMonth);
		if(log.isInfoEnabled()){
			log.info("Leave Method doGetSalary success");
		}
		return jsonObject;
	}
	/**
	 * 获取首页折线图数据，今年与去年对比
	 * @param email
	 * @return
	 */
	@RequestMapping("doGetLineData.do")
	@ResponseBody
	public JSONObject doGetPerformanceOfMonth(String email){
		if(log.isInfoEnabled()){
			log.info("Enter Method doGetPerformanceOfMonth success");
		}
		JSONObject jsonObject = new JSONObject();
		List<Long> performanceOfMonth = orderServiceImpl.getPerformanceOfMonth(email,0);
		List<Long> performanceOfLastYearMonth = orderServiceImpl.getPerformanceOfMonth(email,-1);
		Calendar cale = Calendar.getInstance();
	    Date date = new Date(System.currentTimeMillis());
	    cale.setTime(date);
		List<String> months = DateUtil.getMonths(cale.get(Calendar.MONTH));
		jsonObject.put("result", true);
		jsonObject.put("months", months);
		jsonObject.put("lastyearaccount", performanceOfLastYearMonth);
		jsonObject.put("account", performanceOfMonth);
		if(log.isInfoEnabled()){
			log.info("Leave Method doGetPerformanceOfMonth success");
		}
		return jsonObject;
	}
	/**
	 * 根据地区统计客户数量  未完成
	 * @param email
	 * @return
	 */
	@RequestMapping("getCutostorOrderByArea.do")
	@ResponseBody
	public JSONObject doGetCutostorOrderByArea(String email){
		if(log.isInfoEnabled()){
			log.info("Enter Method dogetCutostorOrderByArea success");
		}
		JSONObject jsonObject = new JSONObject();
		String [] area = new String[]{"黄浦区","徐汇区","长宁区","静安区","普陀区","闸北区","虹口区","杨浦区","闵行区","宝山区","嘉定区","浦东新区","松江区","青浦区","奉贤区","崇明县","金山区"};
		Integer[] value = new Integer[]{100,21,131,312,23,432,45,56,65,6,24,534,53,65,76,97,74};
		jsonObject.put("result", true);
		List<JSONObject> list = new ArrayList<>();
		for(int i =0;i<value.length;i++){
			JSONObject json = new JSONObject();
			json.put("name", area[i]);
			json.put("value", value[i]);
			list.add(json);
		}
		jsonObject.put("data", list);
		if(log.isInfoEnabled()){
			log.info("Leave Method dogetCutostorOrderByArea success");
		}
		return jsonObject;
	}
	/**
	 * 表格数据
	 * @param email
	 * @return
	 */
	@RequestMapping("doOrderTable.do")
	@ResponseBody
	public JSONObject getOrderTableInfo(String email){
		if(log.isInfoEnabled()){
			log.info("Enter Method getTableInfo success");
		}
		List<JSONObject> tableInfoList = staffServiceImpl.getTableInfoList(email);
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("result", true);
		jsonObject.put("list", tableInfoList);
		if(log.isInfoEnabled()){
			log.info("Leave Method getTableInfo success");
		}
		return jsonObject;
	}
	
	/**
	 * 获取easy-pie饼图数据
	 * @param email
	 * @return
	 */
	@RequestMapping("doGetPieData.do")
	@ResponseBody
	public JSONObject getPieInfo(String email){
		if(log.isInfoEnabled()){
			log.info("Enter Method getPieInfo success");
		}
		Double percentOfAccount = orderServiceImpl.getPercentOfAccount(email);
		Double percentOfNum = orderServiceImpl.getPercentOfNum(email);
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("result", true);
		jsonObject.put("percentOfAccount", percentOfAccount);
		jsonObject.put("percentOfNum", percentOfNum);
		if(log.isInfoEnabled()){
			log.info("leave Method getPieInfo success");
		}
		return jsonObject;
	}
	
	/**
	 * 获取投资人和贷款人表格信息
	 * @param email
	 * @return
	 */
	@RequestMapping("doCustomerTable.do")
	@ResponseBody
	public JSONObject getCustomerTableInfo(String email){
		if(log.isInfoEnabled()){
			log.info("Enter Method getCustomerTableInfo success");
		}
		JSONObject jsonObject = new JSONObject();
		List<JSONObject> findInvestorsInfo = investorServiceImpl.findInvestorsInfo(email);
		List<JSONObject> findBorrowersInfo = borrowerServiceImpl.findBorrowersInfo(email);
		jsonObject.put("result", true);
		jsonObject.put("investors", findInvestorsInfo);
		jsonObject.put("borrowers", findBorrowersInfo);
		return jsonObject;
	}
	/**
	 * 获取柱状图数据
	 * @param email
	 * @return
	 */
	@RequestMapping("doGetBarData.do")
	@ResponseBody
	public JSONObject getBarInfo(String email){
		if(log.isInfoEnabled()){
			log.info("Enter Method getBarInfo success");
		}
		JSONObject jsonObject = new JSONObject();
		List<Long> orderCountOfMonth = orderServiceImpl.getOrderCountOfMonth(email, 0);
		List<Long> orderCountOfMonthLastYear = orderServiceImpl.getOrderCountOfMonth(email, -1);
		Calendar cale = Calendar.getInstance();
	    Date date = new Date(System.currentTimeMillis());
	    cale.setTime(date);
		List<String> months = DateUtil.getMonths(cale.get(Calendar.MONTH));
		jsonObject.put("result", true);
		jsonObject.put("months", months);
		jsonObject.put("lastyearaccount", orderCountOfMonthLastYear);
		jsonObject.put("account", orderCountOfMonth);
		if(log.isInfoEnabled()){
			log.info("Enter Method getBarInfo success");
		}
		return jsonObject;
	}
	
	@RequestMapping("doGetStaffTableInfo.do")
	@ResponseBody
	public JSONObject getStaffTableInfo(){
		if(log.isInfoEnabled()){
			log.info("Enter Method getStaffTableInfo success");
		}
		List<JSONObject> staffTableInfo = staffServiceImpl.getStaffTableInfo();
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("result",true);
		jsonObject.put("staffs", staffTableInfo);
		if(log.isInfoEnabled()){
			log.info("Leave Method getStaffTableInfo success");
		}
		return jsonObject;
	}
	
	/**
	 * 获取订单相关所有信息
	 * @param orderid
	 * @return
	 */
	@RequestMapping("doOrderAllInfos.do")
	@ResponseBody
	public JSONObject getOrderAllInfos(String orderid){
		if(log.isInfoEnabled()){
			log.info("Enter Method getOrderAllInfos success");
		} 
		JSONObject jsonObject = new JSONObject();
		JSONObject orderAboutInfos = orderServiceImpl.getOrderAboutInfos(orderid);
		jsonObject.put("result", true);
		jsonObject.put("info", orderAboutInfos);
		if(log.isInfoEnabled()){
			log.info("Leave Method getOrderAllInfos success");
		} 
		return jsonObject;
		
	}
}

package com.qichen.action;

import java.util.Date;
import java.util.UUID;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.qichen.po.Borrower;
import com.qichen.po.Dept;
import com.qichen.po.Investor;
import com.qichen.po.Message;
import com.qichen.po.Order;
import com.qichen.po.OrderSub;
import com.qichen.po.Plan;
import com.qichen.po.Staff;
import com.qichen.service.BorrowerService;
import com.qichen.service.InvestorService;
import com.qichen.service.MessageService;
import com.qichen.service.OrderService;
import com.qichen.service.PlanService;
import com.qichen.service.StaffService;



@Controller
public class RegisterController {

	private static final Logger log = Logger.getLogger(RegisterController.class);
	
	@Resource
	private StaffService staffServiceImpl;
	@Resource
	private BorrowerService borrowerServiceImpl;
	@Resource
	private InvestorService investorServiceImpl;
	@Resource
	private OrderService orderServiceImpl;
	@Resource
	private MessageService messageServiceImpl;
	@Resource
	private PlanService planServiceImpl;
	/**
	 * 邮箱验证controller
	 * @param email
	 * @return
	 */
	@RequestMapping("doValidateEmail.do")
	@ResponseBody
	public JSONObject ValidateEmail(String email){
		if(log.isInfoEnabled()){
			log.info("Enter method ValidateEmail email :"+email);
		}
		Staff staff = staffServiceImpl.getStaffInfo(email);
		JSONObject jsonObject = new JSONObject();
		if (staff==null) {
			jsonObject.put("result", true);
			if(log.isInfoEnabled()){
				log.info("Leave method ValidateEmail result : true");
			}
		}else {
			jsonObject.put("result", false);
			if(log.isInfoEnabled()){
				log.info("Leave method ValidateEmail result : false");
			}
		}
		return jsonObject;
	}
	/**
	 * 注册员工controller
	 * @param email
	 * @param name
	 * @param telephone
	 * @param password
	 * @param dept
	 * @return
	 */
	@RequestMapping("doRegisterStaff.do")
	@ResponseBody
	public JSONObject registerStaff(String email,String name,String telephone,String password,String dept){
		if(log.isInfoEnabled()){
			log.info("Enter method doRegisterStaff email :"+email);
		}
		System.out.println(dept);
		if (!staffServiceImpl.validateDept(dept)) {
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("result", false);
			return jsonObject;
		}else{
		Staff staff = new Staff(email, password, name, Long.valueOf(telephone), new Date(), null, null, null, null, Long.parseLong(dept));
		staffServiceImpl.addStaff(staff);
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("result", true);
		return jsonObject;
		}
	}
	/**
	 * 注册借款人 同时更新员工旗下投资人列表
	 * @param name
	 * @param telephone
	 * @param householdregister
	 * @param creditcardid
	 * @param description
	 * @param address
	 * @param email
	 * @return
	 */
	@RequestMapping("doRegisterBorrower.do")
	@ResponseBody
	public JSONObject registerBorrower(String name,String telephone,String householdregister,String creditcardid,String description ,String address,String email){
		if(log.isInfoEnabled()){
			log.info("Enter method doRegisterBorrower name :"+name);
		}
		String id = UUID.randomUUID().toString();
		long creditcard = 0L;
		if(creditcardid!=null){
			creditcard = Long.valueOf(creditcardid);
		}
		Borrower borrower = new Borrower(id, name, address,Long.valueOf(telephone), description, householdregister,creditcard, null,null);
		borrowerServiceImpl.addBorrower(borrower);
		staffServiceImpl.updateStaffBorrrower(borrower, email);
		JSONObject jsonObject = new JSONObject();
		Object json = JSON.toJSON(borrower);
		jsonObject.put("result", true);
		jsonObject.put("borrower", json);
		if(log.isInfoEnabled()){
			log.info("Leave method doRegisterBorrower success name :"+name);
		}
		return jsonObject;
		
	}
	
	/**
	 * 注册投资人，更新员工手下投资人列表
	 * @param name
	 * @param telephone
	 * @param accountofmoney
	 * @param creditcardid
	 * @param description
	 * @param address
	 * @param email
	 * @return
	 */
	@RequestMapping("doRegisterInvestor.do")
	@ResponseBody
	public JSONObject registerInvestor(String name,String telephone,String accountofmoney,String creditcardid,String description,String address,String email){
		if(log.isInfoEnabled()){
			log.info("Enter method registerBorrower name :"+name);
		}
		String id = UUID.randomUUID().toString();
		long creditcard = 0L;
		if(creditcardid!=null){
			creditcard = Long.valueOf(creditcardid);
		}
		Investor investor = new Investor(id,name,Long.valueOf(telephone),address,description,Long.valueOf(accountofmoney),creditcard,null);
		investorServiceImpl.addInvestor(investor);
		staffServiceImpl.updateStaffInvestor(investor, email);
		JSONObject jsonObject = new JSONObject();
		Object json = JSON.toJSON(investor);
		jsonObject.put("result", true);
		jsonObject.put("investor",json);
		if(log.isInfoEnabled()){
			log.info("Leave method doRegisterBorrower success name :"+name);
		}
		return jsonObject;
	}
	
	/**
	 * 创建订单
	 * @param telephone
	 * @param term
	 * @param account
	 * @param commission
	 * @param type
	 * @param description
	 * @param interest
	 * @return
	 */
	@RequestMapping("doMakeOrder.do")
	@ResponseBody
	public JSONObject registerOrder(String telephone,String term,String account,String commission,String type,String description,String interest,String email){
		if(log.isInfoEnabled()){
			log.info("Enter method registerOrder telephone :"+telephone);
		}
		String id = UUID.randomUUID().toString();
		Order order =new Order(id, Long.valueOf(account), Integer.valueOf(term),Double.valueOf(commission), Double.valueOf(interest),description, Integer.valueOf(type));
		orderServiceImpl.addOrder(order);
		borrowerServiceImpl.updateBorrowerOrder(Long.valueOf(telephone), order);
		staffServiceImpl.updateStaffOrder(order,email);
		JSONObject jsonObject  = new JSONObject();
		
		jsonObject.put("result", true);
		jsonObject.put("orderid", id);
		if(log.isInfoEnabled()){
			log.info("Leave method registerOrder");
		}
		return jsonObject;
		
	}
	
	/**
	 * 验证订单上的号码是否有效
	 * @param telephone
	 * @return
	 */
	@RequestMapping("doValidateTel.do")
	@ResponseBody
	public JSONObject validateTel(String telephone){
		if(log.isInfoEnabled()){
			log.info("Enter method validateTel telephone :"+telephone);
		}
		Boolean flag = borrowerServiceImpl.validateBorrowerByTel(Long.valueOf(telephone));
		JSONObject  jsonObject = new JSONObject();
		jsonObject.put("result", flag);
		if(log.isInfoEnabled()){
			log.info("Leave method validateTel telephone :"+telephone);
		}
		return jsonObject;
	}
	/**
	 * 修改密码
	 * @param email
	 * @param oldpwd
	 * @param newpwd
	 * @return
	 */
	@RequestMapping("doChangePwd.do")
	@ResponseBody
	public JSONObject changePwd(String email,String oldpwd,String newpwd){
		if(log.isInfoEnabled()){
			log.info("Enter method changePwd email :"+email);
		}
		JSONObject jsonObject = new JSONObject();
		boolean b = staffServiceImpl.validateStaff(email, oldpwd);
		if(b==false){
			jsonObject.put("result", b);
			if(log.isInfoEnabled()){
				log.info("Leave method changePwd No Staff");
			}
			return jsonObject;
		}
		boolean flag = staffServiceImpl.changeStaffPwd(newpwd, email);
		jsonObject.put("result", flag);
		if(log.isInfoEnabled()){
			log.info("Leave method changePwd success");
		}
		return jsonObject;
		
	}
	/**
	 * 将订单推入轮播队列
	 * @param email
	 * @param orderid
	 * @return
	 */
	@RequestMapping("doPublishOrder.do")
	@ResponseBody
	public JSONObject publishOrder(String email,String orderid){
		if(log.isInfoEnabled()){
			log.info("Enter method publishOrder email :"+email);
		}
		JSONObject jsonObject = new JSONObject();
		Staff staff = staffServiceImpl.getStaffInfo(email);
		Order order = orderServiceImpl.findOrderById(orderid);
		if(order==null){
			jsonObject.put("result", false);
			return jsonObject;
		}
		OrderSub sub = new OrderSub(orderid,staff.getName(), email, order.getAccount(), order.getTerm(), order.getCommission(), order.getInterest(), order.getDescription(), order.getStatus());
		orderServiceImpl.pushOrderSub(sub);
		jsonObject.put("result", true);
		return jsonObject;
	}
	/**
	 * 发送离线消息
	 * @param title
	 * @param sendToEmail
	 * @param messgae
	 * @param email
	 * @return
	 */
	@RequestMapping("doSendMessage.do")
	@ResponseBody
	public JSONObject  doMessage(String title,String sendToEmail,String messgae,String email){
		if(log.isInfoEnabled()){
			log.info("Enter method doMessage email :"+email);
		}
		JSONObject jsonObject = new JSONObject();
		Date date = new Date();
		if(title==null){
			title="无标题";
		}
		Message message = new Message(title, email, sendToEmail, date, messgae,false);
		messageServiceImpl.addMessage(message);
		jsonObject.put("result", true);
		if(log.isInfoEnabled()){
			log.info("Leave method doMessage email :"+email);
		}
		return jsonObject;
	}
	/**
	 * 保存计划
	 * @param email
	 * @param date
	 * @param description
	 * @param title
	 * @param type
	 * @return
	 */
	@RequestMapping("dosavePlan.do")
	@ResponseBody
	public JSONObject savePlan(String email,Long date,String description,String title,Integer type){
		if(log.isInfoEnabled()){
			log.info("Enter method savePlan email :"+email);
		}
		Date d = new Date(date);
		String id = UUID.randomUUID().toString();
		Plan plan = new Plan(id,title, d, email, description, type);
		planServiceImpl.addPlan(plan);
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("result", true);
		if(log.isInfoEnabled()){
			log.info("Leave method savePlan email :"+email);
		}
		return jsonObject;
	}
	/**
	 * 移除计划
	 * @param id
	 * @return
	 */
	@RequestMapping("removePlan.do")
	@ResponseBody
	public JSONObject removePlan(String id){
		if(log.isInfoEnabled()){
			log.info("Enter method  removePlan success");
		}
		System.out.println(id);
		boolean flag = planServiceImpl.removePlanById(id);
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("result", flag);
		if(log.isInfoEnabled()){
			log.info("Leave method  removePlan success");
		}
		return jsonObject;
		
	}
	/**
	 * 更新计划
	 * @param email
	 * @param date
	 * @param description
	 * @param title
	 * @param type
	 * @param id
	 * @return
	 */
	@RequestMapping("doUpdatePlan.do")
	@ResponseBody
	public JSONObject updatePlan(String email,Long date,String description,String title,Integer type,String id){
		if(log.isInfoEnabled()){
			log.info("Enter method  updatePlan success");
		}
		JSONObject jsonObject = new JSONObject();
		Date d = new Date(date);
		Plan plan = new Plan(id, title, d, email, description, type);
		planServiceImpl.updatePlan(plan);
		jsonObject.put("result", true);
		if(log.isInfoEnabled()){
			log.info("Leave method  updatePlan success");
		}
		return jsonObject;
	
	}
	/**
	 * 完成订单
	 * @param orderid
	 * @param term
	 * @param interest
	 * @param account
	 * @param commission
	 * @param rebate
	 * @param investortel
	 * @param description
	 * @return
	 */
	@RequestMapping("changeOrderInfo.do")
	@ResponseBody
	public JSONObject changeOrderInfo(String orderid ,String term,String interest,String account,String commission,String rebate,String investortel,String description){
		if(log.isInfoEnabled()){
			log.info("Enter method  changeOrderInfo success");
		}
		Order order = new Order(orderid, null, null, Double.valueOf(interest), Long.valueOf(account), Integer.valueOf(term), Double.valueOf(commission), Double.valueOf(rebate), description, 2);
		orderServiceImpl.changeOrder(order);
		investorServiceImpl.addOrder(orderid, Long.valueOf(investortel));
		orderServiceImpl.removeOrderSub(orderid);
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("result", true);
		if(log.isInfoEnabled()){
			log.info("Leave method  changeOrderInfo success");
		}
		return jsonObject;
			
	}
	/**
	 * 给伙伴授权一起编辑订单
	 * @param email
	 * @param orderid
	 * @return
	 */
	@RequestMapping("linkPartner.do")
	@ResponseBody
	public JSONObject linkPartner(String email,String orderid){
		if(log.isInfoEnabled()){
			log.info("Enter method  linkPartner success");
		}
		staffServiceImpl.addOrderToStaff(email, orderid);
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("result", true);
		if(log.isInfoEnabled()){
			log.info("Leave method  linkPartner success");
		}
		return jsonObject;
	}
	/**
	 * 提交订单 等待审批
	 * @param orderid
	 * @param signingdate
	 * @param loandate
	 * @return
	 */
	@RequestMapping("docommitOrder.do")
	@ResponseBody
	public JSONObject commitOrder(String orderid,String signingdate,String loandate){
		if(log.isInfoEnabled()){
			log.info("Enter method  commitOrder success");
		}
		JSONObject jsonObject = new JSONObject();
		orderServiceImpl.commitOrder(orderid, signingdate, loandate);
		jsonObject.put("result", true);
		if(log.isInfoEnabled()){
			log.info("Leave method  commitOrder success");
		}
		return jsonObject;
		
	}
	/**
	 * 移除订单
	 * @param orderid
	 * @return
	 */
	@RequestMapping("doremoveOrder.do")
	@ResponseBody
	public JSONObject removeOrder(String orderid){
		if(log.isInfoEnabled()){
			log.info("Enter method  removeOrder success");
		}
		JSONObject jsonObject = new JSONObject();
		Boolean result = orderServiceImpl.removeOrder(orderid);
		jsonObject.put("result", result);
		if(log.isInfoEnabled()){
			log.info("Leave method  removeOrder success");
		}
		return jsonObject;
	}
	/**
	 * 员工更换部门
	 * @param email
	 * @param deptid
	 * @return
	 */
	@RequestMapping("staffChangeDept.do")
	@ResponseBody
	public JSONObject changeDept(String email,Long deptid){
		if(log.isInfoEnabled()){
			log.info("Enter method  changeDept success");
		}
		Boolean changeDeptByEmail = staffServiceImpl.changeDeptByEmail(email, deptid);
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("result", changeDeptByEmail);
		if(log.isInfoEnabled()){
			log.info("Enter method  changeDept success");
		}
		return jsonObject;
	}
	/**
	 * 移除员工
	 * @param email
	 * @return
	 */
	@RequestMapping("removeStaffDept.do")
	@ResponseBody
	public JSONObject removeStaff(String email){
		if(log.isInfoEnabled()){
			log.info("Enter method  removeStaff success");
		}
		staffServiceImpl.removeStaffByEmail(email);
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("result", true);
		if(log.isInfoEnabled()){
			log.info("Leave method  removeStaff success");
		}
		return jsonObject;
	}
	/**
	 * 移除部门(部门无人员时可移除)
	 * @param deptid
	 * @return
	 */
	@RequestMapping("removeDept.do")
	@ResponseBody
	public JSONObject removeDept(Long deptid){
		if(log.isInfoEnabled()){
			log.info("Enter method  removeDept success");
		}
		staffServiceImpl.removeDeptById(deptid);
		JSONObject jsonObject  = new JSONObject();
		jsonObject.put("result", true);
		if(log.isInfoEnabled()){
			log.info("Leave method  removeDept success");
		}
		return jsonObject;
	}
	/**
	 * 创建新部门
	 * @param newdeptname
	 * @param newdeptid
	 * @return
	 */
	@RequestMapping("newDept.do")
	@ResponseBody
	public  JSONObject setupNewDept(String newdeptname,Long newdeptid){
		if(log.isInfoEnabled()){
			log.info("Enter method  setupNewDept success");
		}
		Dept dept = new Dept(newdeptid, newdeptname);
		Boolean status = staffServiceImpl.setupNewDeptById(dept);
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("result", status);
		if(log.isInfoEnabled()){
			log.info("Leav emethod  setupNewDept success");
		}
		return jsonObject;
	}
	/**
	 * 订单审批通过
	 * @param orderid
	 * @return
	 */
	@RequestMapping("doOverOrder.do")
	@ResponseBody
	public JSONObject overOrder(String orderid){
		if(log.isInfoEnabled()){
			log.info("Enter method  overOrder success");
		}
		staffServiceImpl.changeStatusOrderToOver(orderid);
		JSONObject jsonObject =new JSONObject();
		jsonObject.put("result", true);
		if(log.isInfoEnabled()){
			log.info("Leave method  overOrder success");
		}
		return jsonObject;
	}
	
	@RequestMapping("changeStatusToBack.do")
	@ResponseBody
	public JSONObject changeStatusToBack(String orderid){
		if(log.isInfoEnabled()){
			log.info("Enter method  changeStatusToBack success");
		}
		orderServiceImpl.changeOrderStatus(orderid);
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("result", true);
		return jsonObject;
		
	}
}

package com.qichen.action;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.qichen.po.Borrower;
import com.qichen.po.Investor;
import com.qichen.po.Order;
import com.qichen.po.Staff;
import com.qichen.service.StaffService;


@Controller
public class LoginController {
	
	private static final Logger log = Logger.getLogger(LoginController.class);
	@Resource
	private StaffService staffServiceImpl;
	@RequestMapping("/login.do")
	public String login(){
		if(log.isInfoEnabled()) {
			log.info("Enter method Login init");
		}
		if(log.isInfoEnabled()) {
			log.info("Leave method Login init");
		} 
		return "login";
	}
	@RequestMapping("/doLogin.do")
	public String doLogin(Model model,HttpServletRequest req){
		if(log.isInfoEnabled()) {
			log.info("Enter method doLogin parameter: email="+req.getParameter("email")+"&password="+req.getParameter("password"));
		}
		String email = req.getParameter("email");
		String password = req.getParameter("password");
		boolean b = staffServiceImpl.validateStaff(email, password);
		if(b==true){
			Staff staff = staffServiceImpl.getStaffInfo(email);
			String name = staff.getName();
			Map<String, String> borrowers = staff.getBorrowers();
			Map<String, String> investors = staff.getInvestors();
			List<String> orders = staff.getOrders();
			int size = 0;
			int si=0;
			double s =0;
			if(borrowers!=null){
				size=borrowers.size();
			}
			if(investors!=null){
				size +=investors.size();
			}
			if(orders!=null){
				si = orders.size();
			}
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("staff", staff);
			model.addAttribute("data",jsonObject);
			model.addAttribute("customerCount",size);
			model.addAttribute("orderCount",si);
			model.addAttribute("username", name);
			if(log.isInfoEnabled()) {
				log.info("Leave method doLogin success");
			} 
			return "home";
		}
			if(log.isInfoEnabled()) {
			log.info("Leave method doLogin success, vaidate is error");
			}
			return "404";
		
	}
}

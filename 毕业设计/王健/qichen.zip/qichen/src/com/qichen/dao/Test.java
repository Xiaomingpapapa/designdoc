package com.qichen.dao;



import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.CriteriaDefinition;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;

import com.alibaba.fastjson.JSON;
import com.qichen.po.Borrower;
import com.qichen.po.Collateral;
import com.qichen.po.Dept;
import com.qichen.po.Investor;
import com.qichen.po.Order;
import com.qichen.po.Plan;
import com.qichen.po.Staff;
import com.sun.org.apache.bcel.internal.generic.NEW;



public class Test {

	
	public static void main(String[] args) {
		
		ApplicationContext ctx = new ClassPathXmlApplicationContext("classpath:applicationContext.xml");
	MongoTemplate template = (MongoTemplate) ctx.getBean("mongoTemplate");
	
	String [] area = new String[]{"上海浦东新区20号","上海黄埔区啥12","上海静安区1912号","上海静安区21号"};
	for (int i = 0; i < area.length; i++) {
		if(area[i].indexOf("黄埔区")!=-1){
			System.out.println("包括");
			System.out.println(i);
		}
	}
	/* Calendar cale = Calendar.getInstance();
	 cale.add(Calendar.YEAR,-1);
	 Date time = cale.getTime();
	 System.out.println(time);
 	for(int i=j;i>=0;i--){
		  // 获取当月第一天和最后一天  
	     SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");  
	     String firstday, lastday;  
	     // 获取前月的第一天  
	     cale = Calendar.getInstance();  
	     cale.add(Calendar.MONTH, -i+1);  
	     cale.set(Calendar.DAY_OF_MONTH, 1);  
	     firstday = format.format(cale.getTime());  
	     // 获取前月的最后一天  
	     cale = Calendar.getInstance();  
	     cale.add(Calendar.MONTH, -i);  
	     cale.set(Calendar.DAY_OF_MONTH, 1);  
	     lastday = format.format(cale.getTime());  
	     System.out.println("本月第一天和最后一天分别是 ： " + firstday + " and " + lastday); 
	 }*/
	
/*	for (int i = 24; i >= 0; i--) {
		Calendar calendar = Calendar.getInstance();
	    Date date = new Date(System.currentTimeMillis());
	    calendar.setTime(date);
	    calendar.add(Calendar.WEEK_OF_YEAR, +1);
	    calendar.add(Calendar.MONTH, -i);
	    calendar.set(Calendar.HOUR_OF_DAY, 16);
	    calendar.set(Calendar.SECOND,0);
	    calendar.set(Calendar.MINUTE,0);
	    date = calendar.getTime();
	    Date date2 = new Date(System.currentTimeMillis());
	    calendar.setTime(date2);
	    calendar.add(Calendar.MONTH, -i);
	    calendar.set(Calendar.HOUR_OF_DAY, 16);
	    calendar.set(Calendar.SECOND,0);
	    calendar.set(Calendar.MINUTE,0);
	    date2 = calendar.getTime();
    System.out.println(date);
	}*/
//	  	template.upsert(new Query(Criteria.where("orderid").is("d79b213f-515c-4c00-a4ed-cb35e6af70bd")), new Update().set("status", 1), "Order");
//	template.insert(new Dept(0L,"管理员"));
//	template.insert(new Dept(1000L,"一部"));
//	Staff findOne = template.findOne(new Query(Criteria.where("email").is("www.wj@wj.com")), Staff.class,"Staff");
//	SimpleDateFormat s = new SimpleDateFormat("yyyy-MM-dd");
//	System.out.println(s.format(findOne.getStarttime()));
//	List<String> arrayList = new ArrayList<>();
//	List<String> arrayLis1t = new ArrayList<>();
//	Borrower borrower = new Borrower("6b208c25-54db-4809-9381-d6e81af85326","李雷","江西上饶",17877777177L,"贷款100万","江西",1234567890L,arrayList,arrayLis1t);
//	template.insert(borrower);
	//template.insert(new Dept(100L,"wangjian"),"test");
	//	Dept dept = new Dept(110L,"rich1");
		
	//	String jsonString = JSON.toJSONString(dept);
		
//		template.insert(dept);
//		Student student = template.findOne(new Query(Criteria.where("name").is("wangjian")), Student.class,"collection");
//		Dept student = template.findOne(new Query(Criteria.where("deptid").is(110)),Dept.class,"Dept");
//		System.out.println(student);

	/*for (int i = 0; i < 10; i++) {
		Collateral collateral = new Collateral();
		collateral.setAgelimit(6);
		collateral.setCollateralid(111110L+i);
		collateral.setCollateralvalue(100+i);
		template.insert(collateral);
	}*/
	}
}

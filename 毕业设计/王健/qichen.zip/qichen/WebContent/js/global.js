/**
 * autoCloseAlert的秒数
 * @type Number
 */
var alertSec = 2000;
/**
 * 弹出窗口公共方法
 * @param {} msg 提示信息
 * @param {} second 显示毫秒数
 */ 
function autoCloseAlert(msg, second) {
	if(second == undefined || second == null){
		new $.flavr({
		content:msg,
		buttons: {
			close : { 
				text: '确定',
				style: 'primary'
			}
		}});
	}else{
		new $.flavr({	
		content: msg,
		autoclose: true,
		timeout: second,
		buttons: {
			close : { 
				text: '确定',
				style: 'primary'
			}
		}
	});
	}
}
/**
 * 弹出对话框公共方法
 * @param {} content 内容
 * @param {} confirm 确定按钮回调函数
 * @param {} cancel 取消按钮回调函数
 */
function dialog(content,confirm,cancel){
	new $.flavr({
		content: content,
		buttons: {
			确定: {
				text: '确定',
				style: 'primary',
				action: confirm
			},
			取消: {
				text: '取消',
				action:cancel
			}
		}
	});
}
/**
 * 显示异常信息
 * @param msg
 */
function showExceptionMsg(msg) {
	msg = msg.replace(/\r\n/g, "<br>&nbsp;&nbsp;&nbsp;&nbsp;");
	var flavr = new $.flavr({ 
		content : '发生内部错误', 
		buttons : {
			show : { 
				text: '显示详细信息', 
				id:"exception_show_btn",
				style: 'info', 
				action: function(){ 
					flavr.content("<div style=\"text-align:left;width:auto;max-height:400px;max-width:1000px;overflow:auto;\">"+msg+"<div>"); 
					$("#exception_hide_btn").show();
					$("#exception_show_btn").hide();
					return false;
				}
			},
			hide : { 
				text: '隐藏详细信息', 
				id:"exception_hide_btn",
				style: 'info', 
				action: function(){ 
					flavr.content("操作失败"); 
					$("#exception_show_btn").show();
					$("#exception_hide_btn").hide();
					return false;
				} 
			}, 
			close : {
				text:"关闭"
			} 
		}
	});
	$("#exception_hide_btn").hide();
}

function loadingHtml(elem,url,data,callFun){
	if(data == undefined || data == null)
		data = "";
	if(callFun == undefined || callFun == null)
		callFun = function(){};
	var loading = "<div class=\"contentBar\">";
	loading += "<div id=\"block_1\" class=\"barlittle\"></div>";
	loading += "<div id=\"block_2\" class=\"barlittle\"></div>";
	loading += "<div id=\"block_3\" class=\"barlittle\"></div>";
	loading += "<div id=\"block_4\" class=\"barlittle\"></div>";
	loading += "<div id=\"block_5\" class=\"barlittle\"></div>";
	loading += "</div>";
	if($("#"+elem).html() != loading){
		$("#"+elem).html(loading);
		$("#"+elem).load(url,data,function(response,status,xhr){
			callFun(response,status,xhr);
			if(status == "error"){
				showExceptionMsg(xhr.responseText);
				$("#"+elem).html("");
			}
		});
	}
}

/**
 * 显示loading 动画
 */
function showLoadingView(elem){
	var loading = "<div class=\"contentBar\">";
	loading += "<div id=\"block_1\" class=\"barlittle\"></div>";
	loading += "<div id=\"block_2\" class=\"barlittle\"></div>";
	loading += "<div id=\"block_3\" class=\"barlittle\"></div>";
	loading += "<div id=\"block_4\" class=\"barlittle\"></div>";
	loading += "<div id=\"block_5\" class=\"barlittle\"></div>";
	loading += "</div>";
	$("#"+elem).empty();
	$("#"+elem).html(loading);
}